using Karmak.Integrations.Elk.Identity;
using Karmak.Integrations.Elk.Identity.Retrieval;
using Karmak.Integrations.Ford.Dcds.Api;
using Karmak.Integrations.Ford.Dcds.Auth;
using Karmak.Integrations.Ford.Dcds.Contracts;
using Karmak.Integrations.Ford.Dcds.ElkContextRetrieval;
using Karmak.Integrations.Ford.Dcds.FileDownload;
using Karmak.Integrations.Ford.Dcds.FileUpload;
using Karmak.Integrations.Ford.Dcds.FileUpload.FinancialStatement;
using Karmak.Integrations.Ford.Dcds.FileUpload.PartsReturn;
using MassTransit;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Karmak.Integrations.Ford.Dcds.Configuration
{
    public static class Extensions
    {
        public static IServiceCollection AddFordDcdsServices(this IServiceCollection services, IConfiguration config)
        {
            services.AddKeyedScoped<IContextClient, ContextClient>(
                DcdsElkContextRetriever.ServiceKey,
                (sp, key) =>
                {
                    var http = sp.GetRequiredService<IHttpClientFactory>().CreateClient();
                    var cache = sp.GetRequiredService<HybridCache>();
                    var options = Options.Create(
                        new ContextClientOptions
                        {
                            ClientId = config["Ford:Dcds:ElkContext:ClientId"]!,
                            ClientSecret = config["Ford:Dcds:ElkContext:ClientSecret"]!,
                            Url = config["Ford:Dcds:ElkContext:Url"]!,
                            CacheExpiration = TimeSpan.FromMinutes(30)
                        });

                    return new ContextClient(http, cache, options);
                });

            services.AddTransient<IDcdsElkContextRetriever, DcdsElkContextRetriever>();

            services.AddTransient<ISendFileProcessor, SendFileProcessor>();
            services.AddTransient<IFinancialStatementReceivedProcessor, FinancialStatementReceivedProcessor>();
            services.AddTransient<IPartsReturnProcessor, PartsReturnProcessor>();

            services.AddTransient<IDownloadFilesProcessor, Processor>();

            services.AddHttpClient<IDcdsApiClient, DcdsApiClient>();
            services.AddHttpClient<IOAuthTokenManager, OAuthTokenManager>();

            services.Configure<DcdsApiClientOptions>(options =>
            {
                options.InBoundApiUri = config["Ford:Dcds:InBoundApiUri"]!;
                options.OutBoundApiUri = config["Ford:Dcds:OutBoundApiUri"]!;
            });

            services.Configure<OAuthTokenManagerOptions>(options =>
            {
                options.ClientId = config["Ford:Dcds:ClientId"]!;
                options.ClientSecret = config["Ford:Dcds:ClientSecret"]!;
                options.InboundScope = config["Ford:Dcds:InboundScope"]!;
                options.OutboundScope = config["Ford:Dcds:OutboundScope"]!;
                options.TokenUri = config["Ford:Dcds:TokenUri"]!;
            });

            return services;
        }

        public static void AddDcdsConsumers(this IBusRegistrationConfigurator configurator)
        {
            configurator.AddConsumer<PartsReturnConsumer>()
                .Endpoint(e =>
                 {
                     e.Name = "ford.dcds.partsreturn";
                 });

            configurator.AddConsumer<FinancialStatementReceivedConsumer>()
                .Endpoint(e =>
                 {
                     e.Name = "ford.dcds.financialstatement";
                 });
        }

        public static void ConfigureDcdsConsumers(this IServiceBusBusFactoryConfigurator serviceBusConfig, IBusRegistrationContext context, IConfiguration config)
        {
            serviceBusConfig.Message<FinancialStatementRequestReceived>(t =>
            {
                t.SetEntityName(config["Ford:Dcds:FinancialStatements:TopicName"]!);
            });

            serviceBusConfig.Message<PartsReturnRequestReceived>(t =>
            {
                t.SetEntityName(config["Ford:Dcds:PartsReturn:TopicName"]!);
            });
        }
    }
}
