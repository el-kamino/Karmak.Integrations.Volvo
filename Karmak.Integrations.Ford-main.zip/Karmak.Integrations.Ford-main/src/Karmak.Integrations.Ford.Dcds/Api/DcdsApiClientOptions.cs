﻿namespace Karmak.Integrations.Ford.Dcds.Api
{
    public class DcdsApiClientOptions
    {
        public required string InBoundApiUri { get; set; }
        public required string OutBoundApiUri { get; set; }
    }
}
