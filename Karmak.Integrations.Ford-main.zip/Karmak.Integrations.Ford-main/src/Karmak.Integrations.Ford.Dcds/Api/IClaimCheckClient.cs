﻿namespace Karmak.Integrations.Ford.Dcds.Api
{
    public interface IClaimCheckClient
    {
        Task<string> Retrieve(Uri blobUri);
    }
}
