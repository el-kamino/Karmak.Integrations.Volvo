﻿namespace Karmak.Integrations.Ford.Dcds.FileDownload
{
    public interface IDownloadFilesProcessor
    {
        Task<bool> ProcessAsync();
    }
}