namespace Karmak.Integrations.Ford.Dcds.FileDownload
{
    public class FordShowFileResponse
    {
        public string? Type { get; set; }
        public string? Description { get; set; }
        public string? Name { get; set; }
        public DateTime? DocumentDateTime { get; set; }
        public string? DealerId { get; set; }
        public string? Detail { get; set; }
    }
}