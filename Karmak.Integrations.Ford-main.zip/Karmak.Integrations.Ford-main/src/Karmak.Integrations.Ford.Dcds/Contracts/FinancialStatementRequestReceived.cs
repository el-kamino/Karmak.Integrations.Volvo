namespace Karmak.Integrations.Ford.Dcds.Contracts;

public class FinancialStatementRequestReceived
{
    public required string BlobName { get; set; }
}