﻿
namespace Karmak.Integrations.Ford.Dcds.Contracts;

public class PartsReturnRequestReceived
{
    public required string BlobName { get; set; }
}
