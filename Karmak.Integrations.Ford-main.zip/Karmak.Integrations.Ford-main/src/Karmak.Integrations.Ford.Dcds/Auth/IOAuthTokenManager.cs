﻿namespace Karmak.Integrations.Ford.Dcds.Auth
{
    public interface IOAuthTokenManager
    {
        string ClientId { get; }

        Task<string> GetInboundToken();
        Task<string> GetOutboundToken();
    }
}