namespace Karmak.Integrations.Ford.Dcds
{
    public class DcdsServiceValidationException : Exception
    {
        public DcdsServiceValidationException(string message) 
            : base(message)
        {
        }
    }
}