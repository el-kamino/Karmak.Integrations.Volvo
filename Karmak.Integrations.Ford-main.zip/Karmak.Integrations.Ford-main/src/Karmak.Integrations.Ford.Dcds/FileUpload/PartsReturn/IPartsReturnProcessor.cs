﻿
using Karmak.Integrations.Ford.Dcds.Contracts;

namespace Karmak.Integrations.Ford.Dcds.FileUpload.PartsReturn;

public interface IPartsReturnProcessor
{
    Task ProcessAsync(PartsReturnRequest message);
}