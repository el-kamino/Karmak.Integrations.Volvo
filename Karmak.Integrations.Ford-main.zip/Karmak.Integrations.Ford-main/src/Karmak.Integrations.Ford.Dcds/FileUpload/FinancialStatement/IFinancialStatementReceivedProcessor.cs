﻿using Karmak.Integrations.Ford.Dcds.Contracts;

namespace Karmak.Integrations.Ford.Dcds.FileUpload.FinancialStatement;

public interface IFinancialStatementReceivedProcessor
{
    Task ProcessAsync(FinancialStatementRequest message);
}