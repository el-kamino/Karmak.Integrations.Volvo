using Karmak.Integrations.Ford.Dcds.Api;

namespace Karmak.Integrations.Ford.Dcds.FileUpload.FinancialStatement;

public class SubmitFordFinancialStatementRequest : ISendFileRequest
{
    public string SendType { get; set; }
    public string SendTypeVersion { get; set; }
    public string FileName { get; set; }
    public string DealerId { get; set; }
    public string Detail { get; set; }
    public string AccountNumber { get; set; }
    public string KarmakAccountNumber { get; set; }
}