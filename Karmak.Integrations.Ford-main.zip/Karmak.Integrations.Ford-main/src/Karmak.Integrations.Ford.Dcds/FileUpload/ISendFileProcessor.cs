﻿using Karmak.Integrations.Ford.Dcds.Api;

namespace Karmak.Integrations.Ford.Dcds.FileUpload
{
    public interface ISendFileProcessor
    {
        Task ProcessAsync<TRequest>(TRequest sendRequest) where TRequest : ISendFileRequest;
    }
}