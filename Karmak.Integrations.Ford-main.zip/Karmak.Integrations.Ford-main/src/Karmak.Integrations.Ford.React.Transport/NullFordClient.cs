using Karmak.Integrations.Ford.Common.Logging;
using Karmak.Integrations.Ford.React.Transport.Soap;
using Microsoft.Extensions.Logging;

namespace Karmak.Integrations.Ford.React.Transport
{
    public class NullFordClient : IFordClient
    {
        private readonly ILogger _telemetryClient;

        public NullFordClient(ILogger telemetryClient)
        {
            _telemetryClient = telemetryClient;
        }

        public Task OAuth2_0SendJsonAsync(string jsonPayload, bool isPilot, string entityType, IDictionary<string, string> metadata)
        {
            _telemetryClient.LogInformation("Sending to Ford disabled. Dropping transmission.");
            return Task.CompletedTask;
        }

        public Task<SoapResult> OAuthSendSoapAsync(FordSoapRequest request, IDictionary<string, string> metadata)
        {
            _telemetryClient.LogInformationWithMetadata("Sending to Ford disabled. Dropping transmission.", metadata);
            return Task.FromResult<SoapResult>(new SoapResult.Success(null));
        }
    }
}