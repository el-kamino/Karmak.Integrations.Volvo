using Microsoft.Extensions.Logging;
using Karmak.Integrations.Ford.React.Transport.ExtendedLogging;
using Karmak.Integrations.Ford.React.Transport.Security;

namespace Karmak.Integrations.Ford.React.Transport
{
    public class Configuration
    {
        public ILogger Logger { get; set; }
        public HttpClient HttpClient { get; set; }
        public Uri FordUri { get; set; }
        public string Ford60BaseUri { get; set; }
        public string Ford60PilotBaseUri { get; set; }
        public ExtendedLoggingConfiguration ExtendedLogging { get; set; }
        public IOAuthClient React5AuthClient { get; set; }
        public IOAuthClient React6AuthClient { get; set; }
        public IOAuthClient React6PilotAuthClient { get; set; }
        public Dictionary<string, string> Routes60 { get; set; }

        public class ExtendedLoggingConfiguration
        {
            public IExtendedLoggingClient Client { get; set; }
            public string Module { get; set; }
            public string Application { get; set; }
        }
    }
}
