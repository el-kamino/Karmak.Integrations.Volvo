namespace Karmak.Integrations.Ford.React.Transport.ExtendedLogging
{
    public static class FordLogContentType {
        public const string XML = "application/xml";
        public const string JSON = "application/json";
    }
}
