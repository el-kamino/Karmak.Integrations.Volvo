using System.Threading.Tasks;

namespace Karmak.Integrations.Ford.React.Transport.ExtendedLogging
{
    public interface IApplicationResolver {
        string Resolve();
    }
}
