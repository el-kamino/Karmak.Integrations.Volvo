using Karmak.Integrations.Ford.React.Transport.Soap;

namespace Karmak.Integrations.Ford.React.Transport
{
    public interface IFordClient {
        Task<SoapResult> OAuthSendSoapAsync(FordSoapRequest request, IDictionary<string, string> metadata);
        Task OAuth2_0SendJsonAsync(string jsonPayload, bool isPilot, string entityType, IDictionary<string, string> metadata);
    }
}