using System.Xml.Serialization;

namespace Karmak.Integrations.Ford.React.Transport.Soap
{
    [XmlRoot(Namespace = XmlNamespaces.FordRoutingUrl)]
    public class RespondTo {
        [XmlElement(Namespace = XmlNamespaces.FordRoutingUrl)]
        public string Endpoint { get; set; }
    }
}
