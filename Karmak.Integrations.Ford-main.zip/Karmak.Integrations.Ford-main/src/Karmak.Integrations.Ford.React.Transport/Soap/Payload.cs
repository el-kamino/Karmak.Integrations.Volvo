using System.Xml.Serialization;

namespace Karmak.Integrations.Ford.React.Transport.Soap
{
    [XmlRoot(Namespace = XmlNamespaces.TransportUrl)]
    public class Payload {
        [XmlElement(ElementName = "content")]
        public Content Content { get; set; }
    }
}