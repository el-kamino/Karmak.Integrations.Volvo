using System.Xml.Serialization;

namespace Karmak.Integrations.Ford.React.Transport.Soap
{
    [XmlRoot(Namespace = XmlNamespaces.FordIdUrl)]
    public class FordDealerIdentity {
        [XmlElement(ElementName = "SiteCode", Namespace = XmlNamespaces.FordIdUrl)]
        public Code SiteCodeElement { get; set; } = new Code();

        [XmlIgnore]
        public string SiteCode {
            get => SiteCodeElement.Value;
            set => SiteCodeElement.Value = value;
        }

        [XmlRoot(Namespace = XmlNamespaces.FordIdUrl)]
        public class Code {
            [XmlText] public string Value { get; set; }
        }
    }
}