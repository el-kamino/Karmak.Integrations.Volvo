using System.Collections.Generic;

namespace Karmak.Integrations.Ford.React.Transport.Soap
{
    public class FordSoapRequest {
        public IDictionary<string, IEnumerable<string>> Headers { get; set; } = new Dictionary<string, IEnumerable<string>>();
        public SoapEnvelope Body { get; }
        public string Id => Body?.Header?.MessageID;

        public FordSoapRequest(SoapEnvelope body) {
            Body = body;
        }
    }
}
