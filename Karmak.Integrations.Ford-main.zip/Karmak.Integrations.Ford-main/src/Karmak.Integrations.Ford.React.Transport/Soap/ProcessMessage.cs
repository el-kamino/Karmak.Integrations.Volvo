using System.Xml.Serialization;

namespace Karmak.Integrations.Ford.React.Transport.Soap
{
    [XmlRoot(Namespace = XmlNamespaces.TransportUrl)]
    public class ProcessMessage {
        [XmlElement(ElementName = "payload")]
        public Payload Payload { get; set; }
    }
}