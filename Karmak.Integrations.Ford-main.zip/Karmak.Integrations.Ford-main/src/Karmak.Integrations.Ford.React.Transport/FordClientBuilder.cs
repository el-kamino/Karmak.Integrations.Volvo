using Elk.Core.ExtendedLogging;
using Karmak.Integrations.Ford.React.Transport.ExtendedLogging;
using Karmak.Integrations.Ford.React.Transport.Security;
using Microsoft.Extensions.Logging;

namespace Karmak.Integrations.Ford.React.Transport
{
    public class FordClientBuilder
    {
        private ILogger _logger;
        private IOAuthClient _react5AuthClient;
        private IOAuthClient _react6AuthClient;
        private IOAuthClient _react6PilotAuthClient;
        private HttpClient _httpClient;
        private Uri _fordUri;
        private string _ford60BaseUri;
        private string _ford60PilotBaseUri;
        private Dictionary<string, string> _routes60;
        private IExtendedLoggingClient _extendedLoggingClient;
        private IExtendedLoggingService _extendedLoggingService;
        private string _extendedLoggingModule;
        private string _extendedLoggingApplication;

        public FordClientBuilder WithTelemetry(ILogger logger)
        {
            _logger = logger;

            return this;
        }

        public FordClientBuilder WithHttpClient(HttpClient httpClient)
        {
            _httpClient = httpClient;

            return this;
        }

        /// <summary>
        /// Support Prod and Pilot endpoints/>
        /// </summary>
        /// <param name="fordUri"></param>
        /// <param name="fordPilotUri"></param>
        /// <returns></returns>
        public FordClientBuilder WithFordEnvironment(Uri fordUri, string ford60BaseUri, string ford60PilotBaseUri, Dictionary<string, string> routes60)
        {
            _fordUri = fordUri;
            _ford60BaseUri = ford60BaseUri;
            _ford60PilotBaseUri = ford60PilotBaseUri;
            _routes60 = routes60;
            return this;
        }

        public FordClientBuilder WithExtendedLogging(IExtendedLoggingService extendedLoggingService, string module, string application)
        {
            _extendedLoggingService = extendedLoggingService;
            _extendedLoggingModule = module;
            _extendedLoggingApplication = application;

            return this;
        }

        public FordClientBuilder WithExtendedLogging(IExtendedLoggingClient extendedLoggingClient)
        {
            _extendedLoggingClient = extendedLoggingClient;

            return this;
        }

        public FordClientBuilder WithFordOAuth(IOAuthClient react5Auth)
        {
            _react5AuthClient = react5Auth;
            return this;
        }

        public FordClientBuilder WithFordOAuth20(IOAuthClient react6Auth, IOAuthClient react6PilotAuth)
        {
            _react6AuthClient = react6Auth;
            _react6PilotAuthClient = react6PilotAuth;
            return this;
        }

        public FordClient Build()
        {
            return new FordClient(
                new Configuration
                {
                    Logger = _logger ?? throw new ArgumentException("Telemetry client must be provided"),
                    FordUri = _fordUri ?? throw new ArgumentException("Ford environment URI must be provided"),
                    Ford60BaseUri = _ford60BaseUri,
                    Ford60PilotBaseUri = _ford60PilotBaseUri,
                    HttpClient = _httpClient ?? new HttpClient(),
                    React5AuthClient = _react5AuthClient,
                    React6AuthClient = _react6AuthClient,
                    React6PilotAuthClient = _react6PilotAuthClient,
                    Routes60 = _routes60,
                    ExtendedLogging = new Configuration.ExtendedLoggingConfiguration
                    {
                        Client = BuildExtendedLoggingClient(),
                        Module = _extendedLoggingModule,
                        Application = _extendedLoggingApplication
                    }
                });
        }

        private IExtendedLoggingClient BuildExtendedLoggingClient()
        {
            if (_extendedLoggingClient != null)
            {
                return _extendedLoggingClient;
            }

            if (_extendedLoggingService != null)
            {
                return new ExtendedLoggingClient(_logger, _extendedLoggingService, _extendedLoggingModule, _extendedLoggingApplication);
            }

            return new NullExtendedLoggingClient();
        }
    }
}
