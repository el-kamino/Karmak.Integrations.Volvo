﻿namespace Karmak.Integrations.Ford.React.Transport.Security
{
    public interface IOAuthClient
    {
        Task<string> GetAuthTokenAsync();
    }
}
