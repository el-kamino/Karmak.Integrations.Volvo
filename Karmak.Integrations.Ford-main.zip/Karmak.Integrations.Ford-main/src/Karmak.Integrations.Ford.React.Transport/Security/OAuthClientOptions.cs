﻿namespace Karmak.Integrations.Ford.React.Transport.Security
{
    public class OAuthClientOptions
    {
        public string ClientSecret { get; set; }
        public string ClientId { get; set; }
        public string TokenUri { get; set; }
        public string TokenResource { get; set; }
        public string Scope { get; set; }
    }
}
