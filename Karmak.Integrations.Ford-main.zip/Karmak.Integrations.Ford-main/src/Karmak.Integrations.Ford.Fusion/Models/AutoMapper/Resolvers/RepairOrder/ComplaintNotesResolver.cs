using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.RepairOrder;

public class ComplaintNotesResolver : IValueResolver<FusionComplaintCauseCorrection, RepairOrderTask, string>
{
    public string Resolve(FusionComplaintCauseCorrection source, RepairOrderTask destination, string destMember, ResolutionContext context) =>
        source == null
            ? null
            : string.Concat(source.ComplaintDescription, source.CauseDescription);
}