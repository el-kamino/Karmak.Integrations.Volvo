using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder;
using Karmak.Integrations.Ford.React.Contracts;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.RepairOrder;

public class RepairOrderSnapshotOriginalIdentifierResolver : IValueResolver<FusionRepairOrderSnapshot, RepairOrderSnapshot, IList<ExternalIdentifier>>
{
    public IList<ExternalIdentifier> Resolve(FusionRepairOrderSnapshot source, RepairOrderSnapshot destination, IList<ExternalIdentifier> destMember, ResolutionContext context)
    {
        return new List<ExternalIdentifier>()
        {
            new ExternalIdentifier {
                ID = source.OriginalRepairOrderID,
                ExternalSourceType = "FUSION"
            }
        };
    }
}
