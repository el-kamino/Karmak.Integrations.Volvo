using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.RepairOrder;

public class TaskTaxTotalResolver : IValueResolver<FusionRepairOrderTask, RepairOrderTask, decimal>
{
    public decimal Resolve(FusionRepairOrderTask source, RepairOrderTask destination, decimal destMember, ResolutionContext context)
    {
        return source.TaskTaxTotal ?? 0m;
    }
}