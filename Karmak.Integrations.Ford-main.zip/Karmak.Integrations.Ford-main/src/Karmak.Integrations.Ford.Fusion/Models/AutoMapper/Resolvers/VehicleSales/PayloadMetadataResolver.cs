using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.VehicleSalesOrder;
using Karmak.Integrations.Ford.React.Contracts.Common;
using Karmak.Integrations.Ford.React.Contracts.VehicleSales.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.VehicleSales
{
    public class PayloadMetadataResolver : IValueResolver<FusionVehicleSalesOrder, VehicleSalesOrder, PayloadMetadata>
    {
        public PayloadMetadata Resolve(
            FusionVehicleSalesOrder source,
            VehicleSalesOrder destination,
            PayloadMetadata destMember,
            ResolutionContext context)
        {
            return new PayloadMetadata { FusionVersion = source.DatabaseVersion };
        }
    }
}