using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsInventory;
using Karmak.Integrations.Ford.React.Contracts.Common;
using Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.PartsInventory;

public class PayloadMetadataResolver : IValueResolver<FusionPartsInventoryReport, PartsInventoryReport, PayloadMetadata>
{
    public PayloadMetadata Resolve(FusionPartsInventoryReport source, PartsInventoryReport destination, PayloadMetadata destMember, ResolutionContext context)
    {
        return new PayloadMetadata
        {
            CreatedAtDateTime = source.PartInventoryMetaData.CreatedDateTime,
            FusionVersion = source.PartInventoryMetaData.DatabaseVersion
        };
    }
}
