using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.InterfaceOptions;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.InterfaceOptions;

public class OemUserMappingResolver
    : IValueResolver<FusionFordInterfaceOptions, Ford.Common.Settings.Models.InterfaceOptions, IDictionary<string, string>>
{
    public IDictionary<string, string> Resolve(FusionFordInterfaceOptions source, Ford.Common.Settings.Models.InterfaceOptions destination, IDictionary<string, string> destMember, ResolutionContext context)
    {
        var oemUserMapping = new Dictionary<string, string>();

        foreach (var mapping in source.OEMUserCrossReferences ?? Array.Empty<OEMUserCrossReference>())
        {
            var strippedUsername = mapping.Username.Replace(".", string.Empty);
            oemUserMapping[strippedUsername] = mapping.OEMUserID;
        }

        return oemUserMapping;
    }

}
