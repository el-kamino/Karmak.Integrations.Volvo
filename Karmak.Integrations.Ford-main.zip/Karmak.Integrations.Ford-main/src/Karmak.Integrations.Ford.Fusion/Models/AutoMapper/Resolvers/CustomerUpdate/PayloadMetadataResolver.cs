using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.CustomerUpdate;
using Karmak.Integrations.Ford.React.Contracts.Common;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.CustomerUpdate;

public class PayloadMetadataResolver : IValueResolver<FusionCustomerUpdate, Ford.React.Contracts.CustomerUpdates.Data.CustomerUpdate, PayloadMetadata>
{
    public PayloadMetadata Resolve(
        FusionCustomerUpdate source,
        Ford.React.Contracts.CustomerUpdates.Data.CustomerUpdate destination,
        PayloadMetadata destMember,
        ResolutionContext context)
    {
        return new PayloadMetadata { FusionVersion = source.DatabaseVersion };
    }
}
