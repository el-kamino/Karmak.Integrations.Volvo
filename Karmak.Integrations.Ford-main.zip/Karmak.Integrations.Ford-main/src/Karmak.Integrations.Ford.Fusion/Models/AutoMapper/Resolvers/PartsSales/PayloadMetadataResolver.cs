using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsSalesOrder;
using Karmak.Integrations.Ford.React.Contracts.Common;
using Karmak.Integrations.Ford.React.Contracts.PartSales.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.PartsSales
{
    public class PayloadMetadataResolver : IValueResolver<FusionPartsSalesOrder, PartsSalesOrder, PayloadMetadata> {
        public PayloadMetadata Resolve(
            FusionPartsSalesOrder source,
            PartsSalesOrder destination,
            PayloadMetadata destMember,
            ResolutionContext context) {
            return new PayloadMetadata { FusionVersion = source.DatabaseVersion };
        }
    }
}
