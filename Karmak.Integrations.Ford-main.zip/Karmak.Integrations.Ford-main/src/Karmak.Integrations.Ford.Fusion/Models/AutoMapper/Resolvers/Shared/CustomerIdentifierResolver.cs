using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;
using Karmak.Integrations.Ford.React.Contracts;
using ElkCustomer = Karmak.Integrations.Ford.React.Contracts.Common.Customer;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.Shared
{
    public class CustomerIdentifierResolver : IValueResolver<FusionCustomer, ElkCustomer, IList<ExternalIdentifier>> {
        public IList<ExternalIdentifier> Resolve(FusionCustomer source, ElkCustomer destination, IList<ExternalIdentifier> destMember, ResolutionContext context) {
            var externalIdentifiers = new List<ExternalIdentifier>();
            externalIdentifiers.Add(new ExternalIdentifier {
                ID = source.CustomerID,
                ExternalSourceType = "FUSION"
            });

            if (source.ExternalIdentifiers != null) {
                foreach (FusionExternalIdentifier id in source.ExternalIdentifiers) {
                    externalIdentifiers.Add(new ExternalIdentifier {
                        ID = id.ID,
                        ExternalSourceType = id.ExternalSourceType
                    });
                }
            }
            return externalIdentifiers;
        }
    }
}
