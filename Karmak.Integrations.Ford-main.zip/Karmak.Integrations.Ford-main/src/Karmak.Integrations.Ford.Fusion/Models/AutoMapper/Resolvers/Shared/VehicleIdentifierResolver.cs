using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;
using Karmak.Integrations.Ford.React.Contracts;
using Karmak.Integrations.Ford.React.Contracts.Common;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.Shared
{
    public class VehicleIdentifierResolver : IValueResolver<FusionVehicle, Vehicle, IList<ExternalIdentifier>> {
        public IList<ExternalIdentifier> Resolve(FusionVehicle source, Vehicle destination, IList<ExternalIdentifier> destMember, ResolutionContext context) {
            return new List<ExternalIdentifier>
            {
                new ExternalIdentifier {
                    ID = source.UnitID,
                    ExternalSourceType = "FUSION"
                }
            };
        }
    }
}
