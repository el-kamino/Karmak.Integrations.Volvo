namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper;

public static class Constants
{
    public static readonly string[] FordCustomerTypeCodes = { "A", "B", "D", "F", "G", "I", "J", "R", "W", "U" };
    public static readonly string DefaultCustomerTypeCode = "U";
    public static readonly string FusionIdentityKey = "FusionIdentity";
    public static readonly string TimeZone = "TimeZone";
}
