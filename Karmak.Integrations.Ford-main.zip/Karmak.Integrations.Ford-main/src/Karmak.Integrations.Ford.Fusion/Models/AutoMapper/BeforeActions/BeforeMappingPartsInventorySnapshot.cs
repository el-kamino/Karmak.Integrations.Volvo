using AutoMapper;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsInventory;
using Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.BeforeActions;

public class BeforeMappingPartsInventorySnapshot : IMappingAction<FusionPartsInventoryReport, PartsInventoryReport>
{
    public void Process(FusionPartsInventoryReport source, PartsInventoryReport destination, ResolutionContext context)
    {
        foreach (var part in source.Parts)
        {
            if (part.LastSold == default(DateTime))
            {
                part.LastSold = null;
            }
        }
    }
}
