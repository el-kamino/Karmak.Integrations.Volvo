using AutoMapper;
using Karmak.Integrations.Ford.Common.Settings.Models;
using Karmak.Integrations.Ford.Fusion.Models.AutoMapper.Resolvers.InterfaceOptions;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.InterfaceOptions;

namespace Karmak.Integrations.Ford.Fusion.Models.AutoMapper.MappingProfile;

public class FordInterfaceOptionsMappingProfile : Profile
{
    public FordInterfaceOptionsMappingProfile()
    {
        CreateMap<FusionFordInterfaceOptions, InterfaceOptions>()
            .ForMember(dest => dest.OemUserMappings, opt => opt.MapFrom<OemUserMappingResolver>());
    }
}