namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.FinancialStatement;

public class FusionFordFinancialStatementRequest
{
    public string FinancialFileText { get; set; }
}