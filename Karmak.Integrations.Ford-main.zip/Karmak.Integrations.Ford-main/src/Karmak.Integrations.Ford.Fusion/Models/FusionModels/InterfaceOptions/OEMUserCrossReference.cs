namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.InterfaceOptions;

public class OEMUserCrossReference
{
    public string Username { get; set; }
    public string OEMUserID { get; set; }
}
