namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder
{
    public class FusionRepairOrderSubstatus {
        public const string AT_DEALERSHIP = "At Dealership";
    }
}