namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder
{
    public class FusionPartType {
        public const string REGULAR = "Part";
        public const string EXCHANGE = "Exchange";
        public const string CORE = "Core";
    }
}