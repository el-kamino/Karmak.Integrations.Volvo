using System;

namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder
{
    public class FusionAppointment {
        public DateTime? AppointmentMadeDate { get; set; }
        public DateTime? ArrivalDate { get; set; }
    }
}