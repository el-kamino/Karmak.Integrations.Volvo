namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.RepairOrder
{
    public class FusionSRT {
        public string SRTCode { get; set; }
        public string SRTDescription { get; set; }
        public decimal SRTHours { get; set; }
    }
}
