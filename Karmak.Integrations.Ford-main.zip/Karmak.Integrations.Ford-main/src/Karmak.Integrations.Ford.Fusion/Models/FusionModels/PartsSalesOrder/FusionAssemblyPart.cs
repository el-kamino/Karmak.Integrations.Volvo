namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsSalesOrder
{
    public class FusionAssemblyPart {
        public decimal? UnitCost;
        public decimal? UnitListPrice;
        public decimal? Quantity;
        public string Description;
        public string PartNumber;
        public string PartType;
    }
}
