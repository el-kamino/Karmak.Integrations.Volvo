﻿using Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;

namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.MessagingError;

public class PoisonMessage
{
    public List<Message> Messages { get; set; }
}
