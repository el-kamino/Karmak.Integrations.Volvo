namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsInventory;

public class FusionPartInventoryMetaData
{
    public string RecordSetType { get; set; }
    public string DatabaseVersion { get; set; }
    public DateTime CreatedDateTime { get; set; }
    public int CreatedTimeZone { get; set; }
}
