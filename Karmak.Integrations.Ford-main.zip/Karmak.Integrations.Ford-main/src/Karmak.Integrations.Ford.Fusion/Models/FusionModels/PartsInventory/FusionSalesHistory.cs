namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.PartsInventory;

public class FusionSalesHistory
{
    public DateTime Period { get; set; }
    public decimal QuantitySold { get; set; }
}
