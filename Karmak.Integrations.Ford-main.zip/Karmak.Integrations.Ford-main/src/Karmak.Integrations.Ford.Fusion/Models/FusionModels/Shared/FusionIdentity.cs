namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared
{
    public class FusionIdentity {
        public string AccountCode { get; set; }
        public string BranchId { get; set; }
        public string BranchCode { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }

        public static readonly FusionIdentity SystemUser = new FusionIdentity
        {
            Username = "Fusion",
            AccountCode = null,
            BranchCode = null
        };

        public static readonly FusionIdentity FordRecon = new FusionIdentity
        {
            Username = "FordRecon",
            AccountCode = null,
            BranchCode = null
        };

        public static readonly FusionIdentity FordStatus = new FusionIdentity
        {
            Username = "FordStatus",
            AccountCode = null,
            BranchCode = null
        };

        public static readonly FusionIdentity Ford = new FusionIdentity
        {
            Username = "Ford",
            AccountCode = null,
            BranchCode = null
        };
    }
}
