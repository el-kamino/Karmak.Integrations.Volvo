namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;

public class Message
{
    public string MessageType { get; set; }
    public string MessageText { get; set; }
}
