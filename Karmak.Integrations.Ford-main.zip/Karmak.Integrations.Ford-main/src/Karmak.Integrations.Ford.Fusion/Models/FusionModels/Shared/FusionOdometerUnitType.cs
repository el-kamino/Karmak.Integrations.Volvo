namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared
{
    public enum FusionOdometerUnitType {
        MILES,
        KILOMETERS
    }
}