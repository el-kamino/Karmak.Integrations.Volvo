namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared
{
    public class FusionEngine {
        public decimal? TotalEngineHours { get; set; }
    }
}
