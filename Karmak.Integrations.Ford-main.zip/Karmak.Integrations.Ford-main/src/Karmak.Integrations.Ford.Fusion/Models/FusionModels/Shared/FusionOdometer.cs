namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared
{
    public class FusionOdometer {
        public decimal Reading { get; set; }
        public FusionOdometerUnitType UnitType { get; set; }
    }
}