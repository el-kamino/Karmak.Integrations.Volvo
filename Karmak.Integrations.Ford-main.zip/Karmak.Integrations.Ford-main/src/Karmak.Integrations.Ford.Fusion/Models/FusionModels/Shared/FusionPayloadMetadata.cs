using System;

namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared
{
    public class FusionPayloadMetadata {
        public string DatabaseVersion { get; set; }
        public DateTime CreatedAtDateTime { get; set; }
    }
}