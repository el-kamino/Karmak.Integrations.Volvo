using Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;

namespace Karmak.Integrations.Ford.Fusion.Models.FusionModels.CustomerUpdate;

public class FusionCustomerUpdate
{
    public string DatabaseVersion { get; set; }
    public FusionCustomer Customer { get; set; }
    public int FordPassRewardID { get; set; }
    public bool SentToFord { get; set; }
    public IList<string> CurrentVINs { get; set; }
    public string AddedVIN { get; set; }
    public string RemovedVIN { get; set; }
}
