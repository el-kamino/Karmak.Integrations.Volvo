﻿namespace Karmak.Integrations.Ford.Fusion.Common;

public class InterfaceOptionsDispatchOptions
{
    public string FordInterfaceOptionsRecordDefinitionId { get; set; }
}
