using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.Fusion.Common;

public static class ConfigurationExtensions
{
    public static IServiceCollection AddCommonDispatchers(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<InterfaceOptionsDispatchOptions>(options =>
        {
            options.FordInterfaceOptionsRecordDefinitionId = configuration["Ford:CommonDispatch:InterfaceSettings:FordInterfaceOptionsRecordDefinitionId"];
        });

        services.AddKeyedScoped<IRequestDispatcher, MessagingErrorDispatcher>(MessagingErrorDispatcher.EntityType);
        services.AddKeyedScoped<IRequestDispatcher, InterfaceOptionsDispatch>(InterfaceOptionsDispatch.EntityType);
        return services;
    }
}
