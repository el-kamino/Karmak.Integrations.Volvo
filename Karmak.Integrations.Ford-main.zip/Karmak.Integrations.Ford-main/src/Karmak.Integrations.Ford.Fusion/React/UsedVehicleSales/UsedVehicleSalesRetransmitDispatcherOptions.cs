﻿namespace Karmak.Integrations.Ford.Fusion.React.UsedVehicleSales;

internal class UsedVehicleSalesRetransmitDispatcherOptions
{
    public string QueueName { get; set; }
}
