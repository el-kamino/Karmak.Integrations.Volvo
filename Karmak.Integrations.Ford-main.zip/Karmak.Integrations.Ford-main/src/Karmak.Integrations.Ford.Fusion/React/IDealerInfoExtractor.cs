﻿using Karmak.Integrations.Elk.Identity.Context;
using Karmak.Integrations.Ford.React.Contracts.Common;

namespace Karmak.Integrations.Ford.Fusion.React;

public interface IDealerInfoExtractor
{
    DealerInfo Extract();
    bool TryExtractElkContextToDealerInfo(ElkContext context, out DealerInfo dealerInfo);
}
