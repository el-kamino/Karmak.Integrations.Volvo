﻿using Karmak.Integrations.Ford.Fusion.Models.AutoMapper.MappingProfile;
using Karmak.Integrations.Ford.Fusion.React.CustomerUpdate;
using Karmak.Integrations.Ford.Fusion.React.PartsInventory;
using Karmak.Integrations.Ford.Fusion.React.PartsSalesOrders;
using Karmak.Integrations.Ford.Fusion.React.RepairOrders;
using Karmak.Integrations.Ford.Fusion.React.ServiceAppointment;
using Karmak.Integrations.Ford.Fusion.React.UsedVehicleSales;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.Fusion.React;

public static class ConfigurationExtensions
{
    public static IServiceCollection AddFordReactDispatch(this IServiceCollection services, IConfiguration config)
    {
        services.AddAutoMapper(typeof(RepairOrderMappingProfile));
        services.AddAutoMapper(typeof(PartsSalesOrderMappingProfile));
        services.AddAutoMapper(typeof(VehicleSalesOrderMappingProfile));
        services.AddAutoMapper(typeof(PartsInventoryReportMappingProfile));
        services.AddAutoMapper(typeof(CustomerUpdateMappingProfile));

        services.AddSingleton<IDealerInfoExtractor, DealerInfoExtractor>();

        services.AddRepairOrderDispatch(config);
        services.AddPartsSalesOrderDispatch(config);
        services.AddUsedVehicleSalesDispatch(config);
        services.AddPartsInventoryDispatch();
        services.AddCustomerUpdateDispatch(config);
        services.AddServiceAppointmentsDispatch();

        return services;
    }
}
