﻿namespace Karmak.Integrations.Ford.Fusion.React.RepairOrders;

internal class RepairOrderRetransmitDispatcherOptions
{
    public string QueueName { get; set; }
}
