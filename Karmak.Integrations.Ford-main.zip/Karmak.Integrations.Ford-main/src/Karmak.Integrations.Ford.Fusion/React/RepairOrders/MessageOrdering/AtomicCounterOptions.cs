﻿namespace Karmak.Integrations.Ford.Fusion.React.RepairOrders.MessageOrdering;

internal class AtomicCounterOptions
{
    public string TableConnectionString { get; set; }
    public string TableName { get; set; }
}
