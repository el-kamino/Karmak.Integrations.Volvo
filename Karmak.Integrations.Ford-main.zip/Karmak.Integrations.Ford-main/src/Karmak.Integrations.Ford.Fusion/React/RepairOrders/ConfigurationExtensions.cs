using Karmak.Integrations.Ford.Fusion.React.RepairOrders.MessageOrdering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.Fusion.React.RepairOrders
{
    internal static class ConfigurationExtensions
    {
        public static IServiceCollection AddRepairOrderDispatch(this IServiceCollection services, IConfiguration config)
        {
            services.Configure<RepairOrderRetransmitDispatcherOptions>(options =>
            {
                options.QueueName = config["Ford:React:RepairOrders:RetransmitQueueName"];
            });

            services.Configure<AtomicCounterOptions>(options =>
            {
                options.TableConnectionString = config["Ford:Storage:ConnectionString"];
                options.TableName = config["Ford:React:RepairOrders:CounterTableName"];
            });

            services.AddSingleton<IAtomicCounter, AtomicCounter>();
            services.AddKeyedScoped<IRequestDispatcher, RepairOrderSnapshotDispatcher>(RepairOrderSnapshotDispatcher.EntityType);
            services.AddScoped<IRepairOrderRetransmitDispatcher, RepairOrderRetransmitDispatcher>();

            return services;
        }
    }
}
