﻿namespace Karmak.Integrations.Ford.Fusion.React.CustomerUpdate;

internal class CustomerUpdateRetransmitDispatcherOptions
{
    public string QueueName { get; set; }
}
