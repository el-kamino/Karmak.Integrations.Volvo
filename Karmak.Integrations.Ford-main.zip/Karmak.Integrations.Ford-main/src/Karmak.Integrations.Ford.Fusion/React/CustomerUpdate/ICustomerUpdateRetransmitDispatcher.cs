﻿namespace Karmak.Integrations.Ford.Fusion.React.CustomerUpdate
{
    public interface ICustomerUpdateRetransmitDispatcher
    {
        Task<Guid> RetransmitCustomerUpdateAsync(string paCode, DateTime? beginDateTimeWindow, DateTime? endDateTimeWindow, string[] fordPassIds, string[] vins);
    }
}