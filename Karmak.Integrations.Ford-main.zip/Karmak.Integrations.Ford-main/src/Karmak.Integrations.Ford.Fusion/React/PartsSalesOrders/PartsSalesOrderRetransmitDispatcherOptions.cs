﻿namespace Karmak.Integrations.Ford.Fusion.React.PartsSalesOrders;

internal class PartsSalesOrderRetransmitDispatcherOptions
{
    public string QueueName { get; set; }
}
