﻿using Karmak.Integrations.Ford.Common.BlobClient;
using Karmak.Integrations.Ford.Common.Settings;
using Karmak.Integrations.Ford.Common.Settings.Models;
using Karmak.Integrations.Ford.Dcds;
using Karmak.Integrations.Ford.Dcds.Contracts;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.FinancialStatement;
using MassTransit;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Linq;
using FusionIdentity = Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared.FusionIdentity;

namespace Karmak.Integrations.Ford.Fusion.Dcds
{
    internal class FinancialStatementDispatcher : IRequestDispatcher
    {
        public const string EntityType = "Ford Financial Statement";

        private readonly ISettingsProvider _settingsProvider;
        private readonly IPublishEndpoint _publishEndpoint;
        private readonly IKarmakBlobClient _claimCheckClient;

        public FinancialStatementDispatcher(
            ISettingsProvider settingsProvider,
            IPublishEndpoint publishEndpoint,
            [FromKeyedServices("ClaimCheck")] IKarmakBlobClient claimCheckClient)
        {
            _settingsProvider = settingsProvider;
            _publishEndpoint = publishEndpoint;
            _claimCheckClient = claimCheckClient;
        }

        public async Task DispatchAsync(FusionRequest<JObject> request, FusionIdentity identity)
        {
            var fusionRequestPayload = request.Payload.ToObject<FusionFordFinancialStatementRequest>();

            var message = new FinancialStatementRequest
            {
                FormattedFileContents = fusionRequestPayload.FinancialFileText,
                RequestDate = Utility.AtOffsetInHours(request.CreatedDateTime, request.CreatedTimeZone),
                KarmakAccountNumber = identity.AccountCode
            };

            FordSettings settings = await _settingsProvider.GetSettingsAsync();
            message.PACode = settings.InterfaceOptions.PaCode;

            string blobName = await _claimCheckClient.UploadAsync(message);
            await _publishEndpoint.Publish(new FinancialStatementRequestReceived { BlobName = blobName });
        }
    }
}
