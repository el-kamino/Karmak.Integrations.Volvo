﻿using Karmak.Integrations.Ford.Fusion.Models.FusionModels;
using Karmak.Integrations.Ford.Fusion.Models.FusionModels.Shared;
using Newtonsoft.Json.Linq;

namespace Karmak.Integrations.Ford.Fusion
{
    public interface IRequestDispatcher
    {
        Task DispatchAsync(FusionRequest<JObject> request, FusionIdentity identity);
    }
}
