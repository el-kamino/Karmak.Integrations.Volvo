﻿using Karmak.Integrations.Ford.React.Contracts;
using Karmak.Integrations.Ford.React.Contracts.Common;
using System.Collections.Generic;
using System.Linq;

namespace Karmak.Integrations.Ford.React.Core.Common.V5_14_4
{
    public static class CustomerExtensions
    {
        private const string FUSION_ID = "FUSION";
        private const string FORD_PASS_REWARD_ID = "FordPASSRewardID";

        public static string GetFusionId(this Customer customer) =>
            customer.GetExternalIdentifierBySourceType(FUSION_ID);

        public static string GetFordPassRewardId(this Customer customer) =>
            customer.GetExternalIdentifierBySourceType(FORD_PASS_REWARD_ID);

        public static string SetFordPassRewardId(this Customer customer,string fordPassRewardId) =>
            customer.SetExternalIdentifierBySourceType(FORD_PASS_REWARD_ID,fordPassRewardId);

        private static string GetExternalIdentifierBySourceType(this Customer customer, string source) =>
            customer?.ExternalIdentifiers?.FirstOrDefault(id => id.ExternalSourceType.Equals(source))?.ID;

        private static string SetExternalIdentifierBySourceType(this Customer customer, string source, string id)
        {
            if (customer == null)
                return null;

            if (customer.ExternalIdentifiers == null)
                customer.ExternalIdentifiers = new List<ExternalIdentifier>();

            var existingId = GetExternalIdentifierBySourceType(customer, source);

            if (existingId == id) // it is already set correctly, just leave
                return existingId;

            if (!string.IsNullOrEmpty(existingId))
                customer.ExternalIdentifiers.Remove(new ExternalIdentifier() { ExternalSourceType = source, ID = existingId });

            customer.ExternalIdentifiers.Add(new ExternalIdentifier() { ExternalSourceType = source, ID = id });

            return existingId;
        }
    }
}
