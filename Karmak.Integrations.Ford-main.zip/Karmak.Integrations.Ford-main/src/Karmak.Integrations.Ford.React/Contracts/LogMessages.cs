﻿namespace Karmak.Integrations.Ford.React.Contracts
{
    public static class LogMessages
    {
        //Information messages
        public const string VersionNotEnabled = "{EntityIdentifier} not processed for this version per configuration. {FordVersion}";
        public const string ReceivedPayload = "{EntityIdentifier} received from Service Bus. {FordVersion}";
        public const string RetransmitReceivedPayload = "{EntityIdentifier} retransmit received from Service Bus. {FordVersion}";
        public const string FinishedProcessing = "{EntityIdentifier} finished processing. {FordVersion}";
        public const string ForceTransmission = "{EntityIdentifier} is marked to force transmission. {FordVersion}";

        //Error messages
        public const string FailedValidation = "{EntityIdentifier} failed validation. {FordVersion} Error: {ErrorMessage}";
        public const string InvalidSettings = "{EntityIdentifier} invalid settings found for Ford React. {FordVersion} Error: {ErrorMessage}";
        public const string SnapshotOutOfOrder = "{EntityIdentifier} snapshot is out of order. {FordVersion} Error: {ErrorMessage}";
        public const string CommentsTransmitException = "{EntityIdentifier} transmit comments exception. {FordVersion} Error: {ErrorMessage}";

        //RO Specific log messages
        public const string SendingVehicleArrival = "{EntityIdentifier} has not sent VEHICLE_ARRIVAL, sending initial payload. {FordVersion}";
        public const string SendingTechAllocated = "{EntityIdentifier} has not sent TECHNICIAN_ALLOCATED, sending initial payload. {FordVersion}";
        public const string RoProcessing = "{EntityIdentifier} Repair Order processing for P&A Code {PaCode}. {FordVersion}";
        public const string RoRetransmitting = "{EntityIdentifier} Repair Order retransmitting for P&A Code {PaCode}. {FordVersion}";
        public const string NoCommentChanges = "{EntityIdentifier} no changes to comments. {FordVersion}";
        public const string StatusUndefined = "{EntityIdentifier} did not have a valid Ford status. {FordVersion}";
        public const string UnseenCanceled = "{EntityIdentifier} was deleted, but has not been sent to Ford before. {FordVersion}";
        public const string StatusNew = "{EntityIdentifier} triggered first transmission. {FordVersion} Trigger: {Trigger}";
        public const string StatusRoChanged = "{EntityIdentifier} triggered RO Status change. {FordVersion} Trigger: {Trigger}";
        public const string StatusTaskChanged = "{EntityIdentifier} triggered RO Task Status change. {FordVersion} Trigger: {Trigger}";
        public const string StatusNoChange = "{EntityIdentifier} did not trigger a state transition. {FordVersion}";
        public const string NoTasks = "{EntityIdentifier} had no valid Tasks. {FordVersion}";
        public const string CommentsTransmitted = "{EntityIdentifier} comments transmitted. {FordVersion}";
        public const string CommentsNotTransmitted = "{EntityIdentifier} comments not transmitted, see prior telemetry. {FordVersion}";
    }
}
