namespace Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data
{
    public class QuantitySoldRecord
    {
        public string Period { get; set; }
        public decimal QuantitySold { get; set; }
    }
}