using System;

namespace Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data;

public class PartsInventoryReportClaimCheck
{
    public string BlobName { get; set; }
}