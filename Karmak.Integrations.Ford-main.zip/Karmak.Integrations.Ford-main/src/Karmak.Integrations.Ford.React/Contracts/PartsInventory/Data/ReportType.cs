using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReportType {
        Full,
        Delta
    }
}