using Karmak.Integrations.Ford.React.Contracts.PartsInventory.Data;

namespace Karmak.Integrations.Ford.React.Contracts.PartsInventory.Messages
{
    public class PartsInventoryReportReceived 
    {
        public PartsInventoryReportClaimCheck ReportClaimCheck { get; set; }
    }
}