namespace Karmak.Integrations.Ford.React.Contracts.Common
{
    public static class AddressType {
        public const string SHIP_TO = "Ship-To";
        public const string BILL_TO = "Bill-To";
    }
}
