namespace Karmak.Integrations.Ford.React.Contracts.Common
{
    public class Phone {
        public PhoneType Type { get; set; }
        public string Number { get; set; }
    }
}
