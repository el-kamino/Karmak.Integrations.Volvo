namespace Karmak.Integrations.Ford.React.Contracts.Common
{
    public class Engine {
        public decimal? Hours { get; set; }
    }
}
