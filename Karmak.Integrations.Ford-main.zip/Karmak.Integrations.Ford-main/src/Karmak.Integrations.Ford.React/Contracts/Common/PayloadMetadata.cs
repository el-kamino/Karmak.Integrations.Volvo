using System;

namespace Karmak.Integrations.Ford.React.Contracts.Common;

public class PayloadMetadata
{
    public string FusionVersion { get; set; }
    public DateTime? CreatedAtDateTime { get; set; }
}
