using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Karmak.Integrations.Ford.React.Contracts.Common
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum VehicleCondition {
        New,
        Used,
        Unknown
    }
}
