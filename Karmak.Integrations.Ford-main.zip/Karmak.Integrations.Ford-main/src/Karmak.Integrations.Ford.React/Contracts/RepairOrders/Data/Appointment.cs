using System;

namespace Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data
{
    public class Appointment {
        public DateTime? AppointmentMadeDateTime { get; set; }
        public DateTime? ArrivalDateTime { get; set; }
    }
}