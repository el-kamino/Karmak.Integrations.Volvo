namespace Karmak.Integrations.Ford.React.Contracts.CustomerUpdates.Messages;

public class CustomerUpdateReceived
{
    public string BlobName { get; set; }
}