using System;
using System.Collections.Generic;
using Karmak.Integrations.Ford.React.Contracts.Common;

namespace Karmak.Integrations.Ford.React.Contracts.CustomerUpdates.Data;

public class CustomerUpdate 
{
    public DealerInfo DealerInfo { get; set; }
    public PayloadMetadata Metadata { get; set; }
    public bool ForceTransmission { get; set; }
    public DateTime? AddDate { get; set; }
    public Customer Customer { get; set; }
    public string Source { get; set; }
    public decimal? TimeZone { get; set; }
    public int FordPassRewardID { get; set; }
    public bool SentToFord { get; set; }
    public IList<string> CurrentVINs { get; set; }
    public string AddedVIN { get; set; }
    public string RemovedVIN { get; set; }

    public CustomerUpdate()
    {
        CurrentVINs = new List<string>();
    }
}