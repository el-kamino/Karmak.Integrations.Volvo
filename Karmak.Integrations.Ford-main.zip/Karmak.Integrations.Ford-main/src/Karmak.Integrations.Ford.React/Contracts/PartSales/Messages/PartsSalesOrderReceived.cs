namespace Karmak.Integrations.Ford.React.Contracts.PartSales.Messages;

public class PartsSalesOrderReceived 
{
    public string BlobName { get; set; }
}