﻿namespace Karmak.Integrations.Ford.React.Contracts;

public class ExternalIdentifier
{
    public string ID { get; set; }
    public string ExternalSourceType { get; set; }
}
