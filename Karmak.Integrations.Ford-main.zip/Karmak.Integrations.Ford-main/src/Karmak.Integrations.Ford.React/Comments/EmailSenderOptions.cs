﻿namespace Karmak.Integrations.Ford.React.Comments;

internal class EmailSenderOptions
{
    public string AlertUri { get; set; }
}