﻿using Karmak.Integrations.Ford.Common.Settings.Models;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Karmak.Integrations.Ford.React.Comments
{
    internal interface ICommentsService
    {
        ReceiveCommentsBody BuildCommentsBody(FordSettings settings, RepairOrderSnapshot ro);
        string GetCommentsHash(List<CommentsItem> comments);
        Dictionary<string, string> GetDetailedMetadata(ReceiveCommentsBody commentsBody, IDictionary<string, string> roMetadata);
        Task<string> GetFordOAuthTokenAsync();
        Task<bool> SendCommentsToFordAsync(ReceiveCommentsBody body, string[] reactEmails, Dictionary<string, string> roMetadata);
        bool TokenIsExpired(string token);
    }
}