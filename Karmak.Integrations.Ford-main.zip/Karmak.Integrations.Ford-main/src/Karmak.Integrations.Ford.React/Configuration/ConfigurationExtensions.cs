using Elk.Core.ExtendedLogging;
using Karmak.Integrations.Elk.Identity;
using Karmak.Integrations.Elk.Identity.Retrieval;
using Karmak.Integrations.Ford.React.Contracts;
using Karmak.Integrations.Ford.React.ElkContextRetrieval;
using Karmak.Integrations.Ford.React.Persistence.React;
using Karmak.Integrations.Ford.React.Transport;
using Karmak.Integrations.Ford.React.Transport.Security;
using Karmak.Integrations.Ford.React.Transport.Soap;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Net.Http;
using AzureCosmosClient = Microsoft.Azure.Cosmos.CosmosClient;

namespace Karmak.Integrations.Ford.React.Configuration;

public static partial class ConfigurationExtensions
{
    public static IServiceCollection AddFordReactProcessing(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<ProcessorOptions>(options =>
        {
            options.Environment = config["Ford:React:Environment"];
            options.VersionOptions = config.GetValue<string>("Ford:React:VersionOptions") is { } versionOptionsJson
                ? System.Text.Json.JsonSerializer.Deserialize<EntityVersionOptions>(versionOptionsJson)
                : null;
        });

        services.AddSingleton<ISoapRequestFactory, SoapRequestFactory>();
        services.AddSingleton<IFordExtendedLoggingService, FordExtendedLoggingService>();

        services.AddSingleton(new AzureCosmosClient(config["Ford:React:Database:ConnectionString"]));
        services.AddFordClient(config);

        services.AddScoped<IReactRepositoryWrapper, ReactRepositoryWrapper>();

        services.AddRepairOrdersProcessing(config);
        services.AddPartsSalesProcessing(config);
        services.AddUsedVehicleSalesProcessing(config);
        services.AddCustomerUpdateProcessing(config);
        services.AddPartsInventoryReportProcessing(config);

        services.AddKeyedScoped<IContextClient, ContextClient>(
               ReactElkContextRetriever.ServiceKey,
               (sp, key) =>
               {
                   var http = sp.GetRequiredService<IHttpClientFactory>().CreateClient();
                   var cache = sp.GetRequiredService<HybridCache>();
                   var options = Options.Create(
                       new ContextClientOptions
                       {
                           ClientId = config["Ford:React:ElkContext:ClientId"]!,
                           ClientSecret = config["Ford:React:ElkContext:ClientSecret"]!,
                           Url = config["Ford:React:ElkContext:Url"]!,
                           CacheExpiration = TimeSpan.FromMinutes(30)
                       });

                   return new ContextClient(http, cache, options);
               });

        services.AddTransient<IReactElkContextRetriever, ReactElkContextRetriever>();

        return services;
    }

    private static IServiceCollection AddFordClient(this IServiceCollection services, IConfiguration config)
    {
        if (config.GetValue<bool>("Ford:React:TransmissionEnabled"))
        {
            services.AddKeyedSingleton<IOAuthClient>("React5Auth", (sp, key) =>
            {
                var options = new OAuthClientOptions
                {
                    ClientSecret = config["Ford:React:OAuth:ClientSecret"],
                    ClientId = config["Ford:React:OAuth:ClientId"],
                    TokenResource = config["Ford:React:OAuth:Resource"],
                    TokenUri = config["Ford:React:OAuth:TokenUri"]
                };

                return ActivatorUtilities.CreateInstance<OAuthClient>(sp, Options.Create(options));
            });

            services.AddKeyedSingleton<IOAuthClient>("React6Auth", (sp, key) =>
            {
                var options = new OAuthClientOptions
                {
                    ClientSecret = config["Ford:React:OAuth20:ClientSecret"],
                    ClientId = config["Ford:React:OAuth20:ClientId"],
                    Scope = config["Ford:React:OAuth20:TokenScope"],
                    TokenUri = config["Ford:React:OAuth20:TokenUri"]
                };

                return ActivatorUtilities.CreateInstance<OAuthClient>(sp, Options.Create(options));
            });

            services.AddKeyedSingleton<IOAuthClient>("React6PilotAuth", (sp, key) =>
            {
                var options = new OAuthClientOptions
                {
                    ClientSecret = config["Ford:React:OAuth20:PilotClientSecret"],
                    ClientId = config["Ford:React:OAuth20:PilotClientId"],
                    Scope = config["Ford:React:OAuth20:PilotTokenScope"],
                    TokenUri = config["Ford:React:OAuth20:TokenUri"]
                };

                return ActivatorUtilities.CreateInstance<OAuthClient>(sp, Options.Create(options));
            });

            services.AddScoped<IFordClient>(sp =>
            {
                string ford60BaseUri = config["Ford:React:Ford60BaseEndpoint"];
                string ford60PilotBaseUri = config["Ford:React:Ford60PilotBaseEndpoint"];
                string fordUri = config["Ford:React:FordEndpoint"];
                string roRoute60 = config["Ford:React:RepairOrders:Ford60Route"];

                Dictionary<string, string> routes60 = new Dictionary<string, string>
                {
                    {EntityTypes.RepairOrder, roRoute60}
                };

                HttpClient httpClient = sp
                    .GetRequiredService<IHttpClientFactory>()
                    .CreateClient();

                IExtendedLoggingService extendedLoggingService = sp.GetRequiredService<IExtendedLoggingService>();
                ILogger logger = sp.GetRequiredService<ILogger<FordClient>>();
                IOAuthClient react5Auth = sp.GetRequiredKeyedService<IOAuthClient>("React5Auth");
                IOAuthClient react6Auth = sp.GetRequiredKeyedService<IOAuthClient>("React6Auth");
                IOAuthClient react6PilotAuth = sp.GetRequiredKeyedService<IOAuthClient>("React6PilotAuth");

                var fordClientBuilder = FordClient.Builder()
                    .WithTelemetry(logger)
                    .WithHttpClient(httpClient)
                    .WithFordEnvironment(new Uri(fordUri), ford60BaseUri, ford60PilotBaseUri, routes60)
                    .WithExtendedLogging(extendedLoggingService, Modules.INTEGRATIONS, "Ford")
                    .WithFordOAuth(react5Auth)
                    .WithFordOAuth20(react6Auth, react6PilotAuth);

                return fordClientBuilder.Build();
            });
        }
        else
        {
            services.AddSingleton<IFordClient>(sp =>
            {
                ILogger logger = sp.GetRequiredService<ILogger<NullFordClient>>();
                return new NullFordClient(logger);
            });
        }

        return services;
    }
}
