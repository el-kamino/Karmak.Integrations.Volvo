using Karmak.Integrations.Ford.React.Splitting;
using Karmak.Integrations.Ford.React.Transport.Soap;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Xml.Linq;

namespace Karmak.Integrations.Ford.React.Configuration
{
    public static partial class ConfigurationExtensions
    {
        private static IServiceCollection AddPartsInventoryReportProcessing(this IServiceCollection services, IConfiguration config)
        {
            int maxTransmisionSize = int.Parse(config["Ford:React:MaxTransmissionSizeBytes"]);
            string xpath = $"//{XmlNamespaces.Star.Prefix}:PartsInventoryLine";

            services.AddTransient<IFordRequestSplitter, FordRequestSplitter>(sp =>
            {
                var splitter = new FordRequestSplitter(
                   new LogicalOr<XDocument>(
                       new HasNElementsAtXPath(xpath, 0),
                       new HasNElementsAtXPath(xpath, 1),
                       new IsBelowTransmissionSizeWhenSerialized(maxTransmisionSize)),
                   new SplitXDocumentOnXPath(xpath));
                return splitter;
            });

            return services;
        }
    }
}
