using Karmak.Integrations.Ford.React.CustomerUpdate;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.React.Configuration
{
    public static partial class ConfigurationExtensions
    {
        private static IServiceCollection AddCustomerUpdateProcessing(this IServiceCollection services, IConfiguration config)
        {
            services.AddScoped<IProcessCustomerUpdate, ProcessCustomerUpdate>();
            return services;
        }
    }
}
