using Karmak.Integrations.Ford.React.Contracts.CustomerUpdates.Messages;
using Karmak.Integrations.Ford.React.Contracts.PartSales.Messages;
using Karmak.Integrations.Ford.React.Contracts.PartsInventory.Messages;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Messages;
using Karmak.Integrations.Ford.React.Contracts.VehicleSales.Messages;
using Karmak.Integrations.Ford.React.Core.PartsInventory.V5_14_4;
using Karmak.Integrations.Ford.React.Core.RepairOrders.V5_14_4;
using Karmak.Integrations.Ford.React.Core.RepairOrders.V6_0_0;
using Karmak.Integrations.Ford.React.CustomerUpdate;
using Karmak.Integrations.Ford.React.PartsSalesOrders.V5_14_4;
using Karmak.Integrations.Ford.React.UsedVehicleSales.V5_14_4;
using MassTransit;
using Microsoft.Extensions.Configuration;
using System;

namespace Karmak.Integrations.Ford.React.Configuration
{
    public static partial class ConfigurationExtensions
    {
        public static void AddReactConsumers(this IBusRegistrationConfigurator configurator)
        {
            //These are pub/sub. Explicitly set the subscription name.
            configurator.AddConsumer<RepairOrderReceivedConsumer>()
            .Endpoint(e =>
            {
                e.Name = "ford.react.repairorders.v5";
            });

            //This is the v6 consumer
            configurator.AddConsumer<RepairOrderConsumer>();

            configurator.AddConsumer<PartsSalesOrderConsumer>()
                .Endpoint(e =>
                {
                    e.Name = "ford.react.partssales.v5";
                });

            configurator.AddConsumer<VehicleSalesOrderReceivedConsumer>()
                .Endpoint(e =>
                 {
                     e.Name = "ford.react.vehiclesales.v5";
                 });

            configurator.AddConsumer<ProcessPartsInventoryReport>()
                .Endpoint(e =>
                 {
                     e.Name = "ford.react.partsinventory.v5";
                 });

            configurator.AddConsumer<CustomerUpdateReceivedConsumer>()
                .Endpoint(e =>
                {
                    e.Name = "ford.react.customerupdates.v5";
                });

            //Retransmit is queue based so the name is set on the entity below
            configurator.AddConsumer<RetransmitRepairOrderConsumer>();
            configurator.AddConsumer<RetransmitPartsSalesOrderConsumer>();
            configurator.AddConsumer<RetransmitVehicleSaleConsumer>();
            configurator.AddConsumer<RetransmitCustomerUpdateConsumer>();

            //This is the v6 consumer
            configurator.AddConsumer<RetransmitRepairOrderConsumer60>();
        }

        public static void ConfigureReactConsumers(this IServiceBusBusFactoryConfigurator serviceBusConfig, IBusRegistrationContext context, IConfiguration config)
        {
            serviceBusConfig.Message<RepairOrderReceived>(t =>
            {
                t.SetEntityName(config["Ford:React:RepairOrders:TopicName"]);
            });

            serviceBusConfig.SubscriptionEndpoint<RepairOrderReceived>(
                "ford.react.repairorders.v6",
                e =>
                {
                    e.RequiresSession = true;
                    e.MaxConcurrentSessions = 4;
                    e.MaxConcurrentCallsPerSession = 1;
                    e.SessionIdleTimeout = TimeSpan.FromSeconds(9);

                    e.ConfigureConsumer<RepairOrderConsumer>(context);
                });

            serviceBusConfig.Message<PartsSalesOrderReceived>(t =>
            {
                t.SetEntityName(config["Ford:React:PartSales:TopicName"]);
            });

            serviceBusConfig.Message<VehicleSalesOrderReceived>(t =>
            {
                t.SetEntityName(config["Ford:React:VehicleSales:TopicName"]);
            });

            serviceBusConfig.Message<PartsInventoryReportReceived>(t =>
            {
                t.SetEntityName(config["Ford:React:PartsInventory:TopicName"]);
            });

            serviceBusConfig.Message<CustomerUpdateReceived>(t =>
            {
                t.SetEntityName(config["Ford:React:CustomerUpdates:TopicName"]);
            });

            serviceBusConfig.ReceiveEndpoint(config["Ford:React:RepairOrders:RetransmitQueueName"], endpoint =>
            {
                endpoint.ConfigureConsumer<RetransmitRepairOrderConsumer>(context);
                //This is the v6 consumer
                endpoint.ConfigureConsumer<RetransmitRepairOrderConsumer60>(context);
            });

            serviceBusConfig.ReceiveEndpoint(config["Ford:React:PartSales:RetransmitQueueName"], endpoint =>
            {
                endpoint.ConfigureConsumer<RetransmitPartsSalesOrderConsumer>(context);
            });

            serviceBusConfig.ReceiveEndpoint(config["Ford:React:VehicleSales:RetransmitQueueName"], endpoint =>
            {
                endpoint.ConfigureConsumer<RetransmitVehicleSaleConsumer>(context);
            });

            serviceBusConfig.ReceiveEndpoint(config["Ford:React:CustomerUpdates:RetransmitQueueName"], endpoint =>
            {
                endpoint.ConfigureConsumer<RetransmitCustomerUpdateConsumer>(context);
            });
        }
    }
}
