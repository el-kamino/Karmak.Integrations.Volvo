using Karmak.Integrations.Ford.React.Comments;
using Karmak.Integrations.Ford.React.Core.RepairOrders.V6_0_0;
using Karmak.Integrations.Ford.React.Persistence.RepairOrderHistory;
using Karmak.Integrations.Ford.React.RepairOrders.FordEvents;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Karmak.Integrations.Ford.React.Configuration;

public static partial class ConfigurationExtensions
{
    private static IServiceCollection AddRepairOrdersProcessing(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<EmailSenderOptions>(options =>
        {
            options.AlertUri = config["Ford:React:RepairOrders:Comments:EmailAlertUri"];
        });

        services.Configure<CommentsServiceOptions>(options =>
        {
            options.CommentsBaseUrl = config["Ford:React:RepairOrders:Comments:BaseUri"];
            options.CommentsReceivePath = config["Ford:React:RepairOrders:Comments:ReceivePath"];

            options.ClientId = config["Ford:React:OAuth:ClientId"];
            options.ClientSecret = config["Ford:React:OAuth:ClientSecret"];
            options.Resource = config["Ford:React:OAuth:Resource"];
            options.TokenUri = config["Ford:React:OAuth:TokenUri"];
        });

        services.AddHttpClient<IEmailSender, EmailSender>();
        services.AddHttpClient<ICommentsService, CommentsService>();

        services.AddSingleton<IDocumentStore<FordEventHistory>>(sp =>
        {
            var cc = sp.GetRequiredService<CosmosClient>();
            var options = Options.Create(new DocumentStoreOptions
            {
                CollectionId = config["Ford:React:RepairOrders:DatabaseRepairOrderHistoryCollection"],
                DatabaseId = config["Ford:React:Database:Id"]
            });

            return new DocumentStore<FordEventHistory>(cc, options);
        });

        services.AddScoped<IFordEventHistoryProvider, FordEventHistoryStore>();
        services.AddScoped<IFordRepairOrderStatusEvaluater, FordRepairOrderStatusEvaluator>();
        return services;
    }
}
