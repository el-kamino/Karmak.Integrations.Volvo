namespace Karmak.Integrations.Ford.React.Constants.Shared
{
    public static class ChannelCodes
    {
        public const string EmailChannelCode = "email1";
    }
}