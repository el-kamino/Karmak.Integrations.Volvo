﻿namespace Karmak.Integrations.Ford.React.Constants.Shared
{
    internal class FordMeterType
    {
        public const string Kilometer = "kilometer";
        public const string Mile = "mile";
    }

    public static class FusionMeterType
    {
        public const string Miles = "miles";
        public const string Kilometers = "kilometers";
    }
}
