namespace Karmak.Integrations.Ford.React.Constants.Shared
{
    public static class DspConstants {
        public const string Code = "Karmak";
        public const string ShortCode = "KM";
        public const string Identifier = "KMKF01";
        public const string DefaultCountryCode = "USA";
    }
}