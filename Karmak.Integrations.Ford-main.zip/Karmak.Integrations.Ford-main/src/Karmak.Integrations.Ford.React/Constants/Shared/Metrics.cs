namespace Karmak.Integrations.Ford.React.Constants.Shared
{
    public static class Metrics {
        public const string InvalidSettings = "FoundInvalidSettings";
        public const string InvalidEntity = "InvalidFordReactEntity";
        public const string FailedTransmission = "FordReactTransmissionFailed";
        public const string RepairOrderHitTrigger = "RepairOrderHitTrigger";
        public const string RepairOrderSnapshotOutOfSequence = "RepairOrderSnapshotOutOfSequence";
    }
}