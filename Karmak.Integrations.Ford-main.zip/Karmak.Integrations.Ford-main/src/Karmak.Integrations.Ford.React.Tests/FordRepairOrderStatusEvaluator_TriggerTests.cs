using Karmak.Integrations.Ford.Common.BlobClient;
using Karmak.Integrations.Ford.React.Core.RepairOrders.Gen.V6_0_0;
using Karmak.Integrations.Ford.React.Core.RepairOrders.V6_0_0;
using Microsoft.Extensions.Logging.Abstractions;
using NSubstitute;
using Xunit;

namespace Karmak.Integrations.Ford.React.Tests.RepairOrders.V6_0_0
{
    public class FordRepairOrderStatusEvaluator_TriggerTests
    {
        private readonly NullLogger<FordRepairOrderStatusEvaluator> _mockLogger;
        private readonly IKarmakBlobClient _mockBlobClient;
        private readonly Dictionary<string, string> _metaData;

        public FordRepairOrderStatusEvaluator_TriggerTests()
        {
            _mockLogger = new NullLogger<FordRepairOrderStatusEvaluator>();
            _mockBlobClient = Substitute.For<IKarmakBlobClient>();
            _metaData = new Dictionary<string, string>
            {
                { "RepairOrder.Number", "TEST-RO-123" }
            };
        }

        [Fact]
        public void RoTrigger_ShouldReturnFalse_WhenCurrentStatusIsUndefined()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.UNDEFINED,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, true);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void RoTrigger_ShouldReturnTrue_WhenFirstTransmissionWithValidStatus()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.ARRIVED,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldTriggerPhantomVEHICLE_ARRIVAL_WhenFirstTransmissionWithValidStatusIsNotVEHICLE_ARRIVAL()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                HasSentVehicleArrival = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var roEvaluator = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient);
            var shouldSend = roEvaluator.RepairOrderTriggersSend(currentState, lastRoWithState, false);
            var result = roEvaluator.ShouldSendPhantomVehicleArrival(currentState);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldNotTriggerPhantomVEHICLE_ARRIVAL_WhenFirstTransmissionIsVEHICLE_ARRIVAL()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                HasSentVehicleArrival = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.ARRIVED,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var roEvaluator = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient);
            var shouldSend = roEvaluator.RepairOrderTriggersSend(currentState, lastRoWithState, false);
            var result = roEvaluator.ShouldSendPhantomVehicleArrival(currentState);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void RoTrigger_ShouldNotTriggerPhantomVEHICLE_ARRIVAL_WhenHasBeenSent()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                HasSentVehicleArrival = true,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.ARRIVED,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var roEvaluator = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient);
            var shouldSend = roEvaluator.RepairOrderTriggersSend(currentState, lastRoWithState, false);
            var result = roEvaluator.ShouldSendPhantomVehicleArrival(currentState);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void RoTrigger_ShouldTriggerPhantomTECHNICIAN_ALLOCATED_WhenHasNotBeenSent()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                HasSentTechnicianAllocated = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var roEvaluator = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient);
            var result = roEvaluator.ShouldSendPhantomTechnicianAllocated(currentState);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldNotTriggerPhantomTECHNICIAN_ALLOCATED_WhenHasBeenSent()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = true,
                HasSentTechnicianAllocated = true,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.UNDEFINED, true);

            // Act
            var roEvaluator = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient);
            var result = roEvaluator.ShouldSendPhantomTechnicianAllocated(currentState);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void RoTrigger_ShouldReturnTrue_WhenRepairOrderStatusChanges()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldReturnTrue_WhenTaskIsDeleted()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.IN_PROGRESS, false);
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 1,
                FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
            });

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.True(result);    
        }

        [Fact]
        public void RoTrigger_ShouldReturnTrue_WhenTaskStatusChanges()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>
                    {
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 1,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 2,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.WORK_NOT_STARTED
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 3,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.COMPLETED
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 4,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.ON_HOLD
                        }
                    }
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.IN_PROGRESS, false);
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 1,
                FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 2,
                FordRoTaskStatus = FordRepairOrderTaskStatus.WORK_NOT_STARTED
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 3,
                FordRoTaskStatus = FordRepairOrderTaskStatus.COMPLETED
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 4,
                FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
            });

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldReturnTrue_WhenTaskIsAdded()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>
                    {
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 1,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
                        }
                    }
                }
            };

            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.IN_PROGRESS, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void RoTrigger_ShouldReturnFalse_WhenNoChanges()
        {
            // Arrange
            var currentState = new FordRepairOrderState
            {
                IsFirstTransmission = false,
                RepairOrderStatusState = new FordRepairOrderStatusState

                {
                    FordRoStatus = FordRepairOrderStatus.IN_PROGRESS,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>
                    {
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 1,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 2,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.WORK_NOT_STARTED
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 3,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.COMPLETED
                        },
                        new FordRepairOrderTaskStatusState
                        {
                            TaskNumber = 4,
                            FordRoTaskStatus = FordRepairOrderTaskStatus.ON_HOLD
                        }
                    }
                }
            };
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.IN_PROGRESS, false);
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 1,
                FordRoTaskStatus = FordRepairOrderTaskStatus.IN_PROGRESS
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 2,
                FordRoTaskStatus = FordRepairOrderTaskStatus.WORK_NOT_STARTED
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 3,
                FordRoTaskStatus = FordRepairOrderTaskStatus.COMPLETED
            });
            lastRoWithState.RepairOrderStatusState.TaskStatusStates.Add(new FordRepairOrderTaskStatusState
            {
                TaskNumber = 4,
                FordRoTaskStatus = FordRepairOrderTaskStatus.ON_HOLD
            });

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).RepairOrderTriggersSend(
                currentState, lastRoWithState, false);

            // Assert
            Assert.False(result);
        }

        private FordRepairOrderState CreateFordRepairOrderWithState(string status, bool isFirstTransmission)
        {
            return new FordRepairOrderState
            {
                IsFirstTransmission = isFirstTransmission,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = status,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
        }
    }
}