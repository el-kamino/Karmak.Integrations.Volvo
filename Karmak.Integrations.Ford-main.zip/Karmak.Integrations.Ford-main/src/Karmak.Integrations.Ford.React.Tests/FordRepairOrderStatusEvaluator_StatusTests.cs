using Karmak.Integrations.Ford.Common.BlobClient;
using Karmak.Integrations.Ford.React.Contracts.RepairOrders.Data;
using Karmak.Integrations.Ford.React.Core.RepairOrders.Gen.V6_0_0;
using Karmak.Integrations.Ford.React.Core.RepairOrders.V6_0_0;
using Microsoft.Extensions.Logging.Abstractions;
using NSubstitute;
using Xunit;

namespace Karmak.Integrations.Ford.React.Tests.RepairOrders.V6_0_0
{
    public class FordRepairOrderStatusEvaluator_StatusTests
    {
        private readonly NullLogger<FordRepairOrderStatusEvaluator> _mockLogger;
        private readonly IKarmakBlobClient _mockBlobClient;
        private readonly Dictionary<string, string> _metaData;

        public FordRepairOrderStatusEvaluator_StatusTests()
        {
            _mockLogger = new NullLogger<FordRepairOrderStatusEvaluator>();
            _mockBlobClient = Substitute.For<IKarmakBlobClient>();
            _metaData = new Dictionary<string, string>
            {
                { "RepairOrder.Number", "TEST-RO-123" }
            };
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnCanceled_WhenRepairOrderIsVoidedAndRoHasNotBeenClosed()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.VOIDED);
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.CANCELED, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnUndefined_WhenRepairOrderIsVoidedAndRoHasBeenClosed()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.VOIDED);
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, true);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.UNDEFINED, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnUndefined_WhenRepairOrderIsAtDealershipAndWeHaveSentThat()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.VOIDED);
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, true, true);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.UNDEFINED, result.FordRoStatus);
        }

        [Theory]
        [InlineData(RepairOrderStatus.CLOSED)]
        [InlineData(RepairOrderStatus.INVOICED)]
        public void RepairOrderStatus_ShouldReturnClosed_WhenRepairOrderIsClosedOrInvoiced(string status)
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(status);
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.CLOSED, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnOnHold_WhenAllTasksAreOnHold()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.HOLD,
                LaborEntries = new List<Labor>()
            });
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.WAITING_FOR_PARTS,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.ON_HOLD, result.FordRoStatus);
        }

        [Theory]
        [InlineData(RepairOrderStatus.OPEN, RepairOrderTaskStatus.HOLD)]
        [InlineData(RepairOrderStatus.OPEN, RepairOrderTaskStatus.WAITING_FOR_PARTS)]
        [InlineData(RepairOrderStatus.OPEN, RepairOrderTaskStatus.CLOSED)]
        [InlineData(RepairOrderStatus.OPEN, RepairOrderTaskStatus.QUOTE_DECLINED)]
        public void RepairOrderStatus_ShouldReturnReOpened_WhenOpenRoHasBeenClosedBefore(string roStatus, string taskStatus)
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(roStatus);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = taskStatus,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, true);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.RE_OPENED, result.FordRoStatus);
        }

        [Theory]
        [InlineData(RepairOrderStatus.CLOSED, RepairOrderTaskStatus.HOLD)]
        [InlineData(RepairOrderStatus.CLOSED, RepairOrderTaskStatus.WAITING_FOR_PARTS)]
        [InlineData(RepairOrderStatus.CLOSED, RepairOrderTaskStatus.CLOSED)]
        [InlineData(RepairOrderStatus.CLOSED, RepairOrderTaskStatus.QUOTE_DECLINED)]
        [InlineData(RepairOrderStatus.INVOICED, RepairOrderTaskStatus.HOLD)]
        [InlineData(RepairOrderStatus.INVOICED, RepairOrderTaskStatus.WAITING_FOR_PARTS)]
        [InlineData(RepairOrderStatus.INVOICED, RepairOrderTaskStatus.CLOSED)]
        [InlineData(RepairOrderStatus.INVOICED, RepairOrderTaskStatus.QUOTE_DECLINED)]
        public void RepairOrderStatus_ShouldReturnClosed_WhenClosedOrInvoicedRoHasBeenClosedBefore(string roStatus, string taskStatus)
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(roStatus);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = taskStatus,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, true);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.CLOSED, result.FordRoStatus);
        }


        [Fact]
        public void RepairOrderStatus_ShouldReturnContacted_WhenAllTasksCompleteAndCustomerContacted()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.CustomerContactedStatus = RepairOrderSubstatus.READY_FOR_PICKUP;
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.CLOSED,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal( FordRepairOrderStatus.CONTACTED, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnInProgress_WhenRoHasLaborEntries()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.HOLD,
            });
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 2,
                RepairTaskStatus = RepairOrderTaskStatus.CLOSED,
            });
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 3,
                RepairTaskStatus = RepairOrderTaskStatus.OPEN,
                LaborEntries = new List<Labor> { new Labor() }
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.IN_PROGRESS, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnArrived_WhenSubStatusIsAtDealership()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.SubStatus = RepairOrderSubstatus.AT_DEALERSHIP;
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.ARRIVED, result.FordRoStatus);
        }

        [Fact]
        public void RepairOrderStatus_ShouldReturnUndefined_WhenNoStatusMatches()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Equal(FordRepairOrderStatus.UNDEFINED, result.FordRoStatus);
        }

        [Theory]
        [InlineData(RepairOrderTaskStatus.HOLD, FordRepairOrderTaskStatus.ON_HOLD)]
        [InlineData(RepairOrderTaskStatus.WAITING_FOR_PARTS, FordRepairOrderTaskStatus.ON_HOLD)]
        [InlineData(RepairOrderTaskStatus.CLOSED, FordRepairOrderTaskStatus.COMPLETED)]
        [InlineData(RepairOrderTaskStatus.QUOTE_DECLINED, FordRepairOrderTaskStatus.DECLINED)]
        public void TaskStatus_ShouldReturnCorrectTaskStatus(string taskStatus, string expectedFordStatus)
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = taskStatus,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Single(result.TaskStatusStates);
            Assert.Equal(expectedFordStatus, result.TaskStatusStates[0].FordRoTaskStatus);
        }

        [Theory]
        [InlineData(RepairOrderTaskStatus.HOLD, FordRepairOrderTaskStatus.COMPLETED)]
        [InlineData(RepairOrderTaskStatus.WAITING_FOR_PARTS, FordRepairOrderTaskStatus.COMPLETED)]
        [InlineData(RepairOrderTaskStatus.CLOSED, FordRepairOrderTaskStatus.COMPLETED)]
        [InlineData(RepairOrderTaskStatus.QUOTE_DECLINED, FordRepairOrderTaskStatus.DECLINED)]
        public void TaskStatus_ShouldReturnCompletedOrDeclinedIfRoIsClosed(string taskStatus, string expectedFordStatus)
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.CLOSED);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = taskStatus,
                LaborEntries = new List<Labor>()
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);  

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Single(result.TaskStatusStates);
            Assert.Equal(expectedFordStatus, result.TaskStatusStates[0].FordRoTaskStatus);
        }


        [Fact]
        public void TaskStatus_ShouldReturnInProgress_WhenTaskHasLaborEntries()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.OPEN,
                LaborEntries = new List<Labor> { new Labor() }
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Single(result.TaskStatusStates);
            Assert.Equal(FordRepairOrderTaskStatus.IN_PROGRESS, result.TaskStatusStates[0].FordRoTaskStatus);
        }

        [Fact]
        public void TaskStatus_ShouldReturnNotStarted_WhenTaskHasNoLaborEntries()
        {
            // Arrange
            var repairOrder = CreateRepairOrderSnapshot(RepairOrderStatus.OPEN);
            repairOrder.Tasks.Add(new RepairOrderTask
            {
                TaskNumber = 1,
                RepairTaskStatus = RepairOrderTaskStatus.OPEN
            });
            var lastRoWithState = CreateFordRepairOrderWithState(FordRepairOrderStatus.ARRIVED, false, false);

            // Act
            var result = new FordRepairOrderStatusEvaluator(_mockLogger, _mockBlobClient).GetFordRepairOrderStatus(repairOrder, lastRoWithState);

            // Assert
            Assert.Single(result.TaskStatusStates);
            Assert.Equal(FordRepairOrderTaskStatus.WORK_NOT_STARTED, result.TaskStatusStates[0].FordRoTaskStatus);
        }


        private RepairOrderSnapshot CreateRepairOrderSnapshot(string status)
        {
            return new RepairOrderSnapshot
            {
                RepairOrderStatus = status,
                SubStatus = string.Empty,
                CustomerContactedStatus = string.Empty,
                Tasks = new List<RepairOrderTask>()
            };
        }

        private FordRepairOrderState CreateFordRepairOrderWithState(string status, bool hasSentVehicleArrived, bool roHasBeenClosed)
        {
            return new FordRepairOrderState
            {
                HasSentVehicleArrival = hasSentVehicleArrived,
                RoHasBeenClosed = roHasBeenClosed,
                RepairOrderStatusState = new FordRepairOrderStatusState
                {
                    FordRoStatus = status,
                    TaskStatusStates = new List<FordRepairOrderTaskStatusState>()
                }
            };
        }

    }
}