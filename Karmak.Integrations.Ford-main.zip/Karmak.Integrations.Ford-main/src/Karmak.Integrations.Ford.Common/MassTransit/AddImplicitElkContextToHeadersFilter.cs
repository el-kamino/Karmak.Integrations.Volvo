using Karmak.Integrations.Elk.Identity;
using MassTransit;

namespace Karmak.Integrations.Ford.Common.MassTransit
{
    internal class AddImplicitElkContextToHeadersFilter<T> : IFilter<T> where T : class, SendContext
    {
        public Task Send(T context, IPipe<T> next)
        {
            context.AddImplicitElkContext(ImplicitElkContext.Current);
            return Task.CompletedTask;
        }

        public void Probe(ProbeContext context)
        {
        }
    }
}