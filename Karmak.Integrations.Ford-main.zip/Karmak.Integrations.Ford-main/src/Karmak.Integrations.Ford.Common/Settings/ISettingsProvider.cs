using Karmak.Integrations.Ford.Common.Settings.Models;

namespace Karmak.Integrations.Ford.Common.Settings
{
    public interface ISettingsProvider
    {
        Task<FordSettings> GetSettingsAsync();
        Task<KicqSettings> GetBridgeSettingsAsync();
        Task UpdateRecordAsync(SettingsRecord document);
    }
}
