﻿namespace Karmak.Integrations.Ford.Common.Settings.Models
{
    public class KicqSettings
    {
        public BridgeSettings BridgeSettings { get; set; }
        public FusionIdentity FusionIdentity { get; set; }
    }
}
