﻿using Newtonsoft.Json;

namespace Karmak.Integrations.Ford.Common.Settings.Models;

public class FordSettings
{
    [JsonProperty("Ford.DealerServiceProviderSettings")]
    public DealerServiceProviderSettings DealerServiceProviderSettings { get; set; }

    [JsonProperty("Ford.RegionSettings")]
    public RegionSettings RegionSettings { get; set; }

    [JsonProperty("Ford.InterfaceOptions")]
    public InterfaceOptions InterfaceOptions { get; set; }
}
