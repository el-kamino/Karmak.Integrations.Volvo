﻿namespace Karmak.Integrations.Ford.Common.BlobClient;

public class KarmakBlobClientOptions
{
    public string StorageConnectionString { get; set; }
    public string ContainerName { get; set; }
}
