﻿namespace Karmak.Integrations.Ford.Inbox;

public class InboxRepositoryOptions
{
    public int EarliestNumberOfDaysToRetrieveMessages { get; set; }
}
