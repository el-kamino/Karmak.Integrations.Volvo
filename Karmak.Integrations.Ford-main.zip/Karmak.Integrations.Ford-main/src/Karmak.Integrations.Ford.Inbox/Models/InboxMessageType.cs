namespace Karmak.Integrations.Ford.Inbox.Models
{
    public enum InboxMessageType
    {
        FixedWidthFile,
        SendFordFileResponse,
        ConfirmBod
    }
}