namespace Karmak.Integrations.Ford.Inbox.Models.Dto;

public class BulkMessageUpdateArguments
{
    public List<InboxMessageUpdateArguments>? Messages { get; set; }
}