namespace Karmak.Integrations.Ford.Inbox.Models.Dto;

public class InboxMessageContents
{
    public string Id { get; set; }
    public IEnumerable<InboxMessageContentLine> Lines { get; set; }
}