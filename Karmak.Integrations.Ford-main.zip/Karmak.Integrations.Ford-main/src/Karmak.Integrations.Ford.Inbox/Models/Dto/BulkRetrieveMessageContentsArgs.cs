namespace Karmak.Integrations.Ford.Inbox.Models.Dto;

public class BulkRetrieveMessageContentsArgs
{
    public List<string>? MessageIds { get; set; }
}