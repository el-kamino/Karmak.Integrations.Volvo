namespace Karmak.Integrations.Ford.Inbox.Models.Dto;

public class InboxMessageContentLine
{
    public int LineNumber { get; set; }
    public string Contents { get; set; }
}