namespace Karmak.Integrations.Ford.Inbox.Models;

public class FixedWidthLine
{
    public int LineNumber { get; set; }
    public string? Contents { get; set; }
}