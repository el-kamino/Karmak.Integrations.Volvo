namespace Karmak.Integrations.Ford.Inbox.Models;

public class MessageContentPointer
{
    public string MessageId { get; set; }
    public string ContentUri { get; set; }
}