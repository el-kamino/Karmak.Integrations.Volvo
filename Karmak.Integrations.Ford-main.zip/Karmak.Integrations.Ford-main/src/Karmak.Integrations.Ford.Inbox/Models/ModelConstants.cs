namespace Karmak.Integrations.Ford.Inbox.Models;

public static class ModelConstants
{
    public const string OEM_NAME_FORD = "FORD";
}