using Karmak.Integrations.Ford.Inbox.Models;
using Karmak.Integrations.Ford.Inbox.Storage.Table;
using Karmak.Integrations.Ford.Inbox.Validators.Blob;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.Inbox.Configuration
{
    public static class Extensions
    {
        public static IServiceCollection AddInboxServices(this IServiceCollection services, IConfiguration config)
        {
            services.AddSingleton<IInboxRepository, InboxRepository>();
            services.AddSingleton<IMetaDataStore<MetaMessageEnvelope>, MetaDataStore<MetaMessageEnvelope>>();
            services.AddSingleton<IStorageClient, StorageClient>();
            services.AddSingleton<IInboxService, InboxService>();

            services.Configure<BlobStorageOptions>(options =>
            {
                options.BlobConnectionString = config["Ford:Inbox:BlobConnectionString"];
                options.ContainerName = config["Ford:Inbox:ContainerName"];
            });

            services.Configure<MetaDataStoreOptions>(options =>
            {
                options.TableConnectionString = config["Ford:Inbox:TableConnectionString"];
                options.TableName = config["Ford:Inbox:TableName"];
            });

            services.Configure<InboxRepositoryOptions>(options =>
            {
                options.EarliestNumberOfDaysToRetrieveMessages = config.GetValue<int>("Ford:Inbox:EarliestNumberOfDaysToRetrieveMessages");
            });

            return services;
        }
    }
}
