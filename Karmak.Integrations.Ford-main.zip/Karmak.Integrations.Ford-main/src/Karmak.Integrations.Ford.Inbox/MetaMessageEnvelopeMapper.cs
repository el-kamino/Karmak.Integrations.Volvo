using Karmak.Integrations.Ford.Inbox.Models;

namespace Karmak.Integrations.Ford.Inbox;

public static class MetaMessageEnvelopeMapper
{
    public static MetaMessageEnvelope Map(FixedWidthFile file, (string, string) accountAndBranch,
           string contentUri)
    {
        var (accountNumber, branchId) = accountAndBranch;

        return new MetaMessageEnvelope
        {
            AccountNumber = accountNumber,
            BranchId = branchId,
            PACode = file.PACode,
            IsActive = true,
            SystemCreatedDate = DateTime.UtcNow,
            SystemLastModifiedDate = DateTime.UtcNow,
            MessageType = InboxMessageType.FixedWidthFile,
            FileName = file.FileName,
            FileType = file.FileType,
            SourceId = file.SourceId,
            Oem = ModelConstants.OEM_NAME_FORD,
            ContentUri = contentUri,
            CreatedDate = DateTime.SpecifyKind(file.CreatedDate, DateTimeKind.Utc),
            FileDescription = file.FileDescription
        };
    }
}