﻿namespace Karmak.Integrations.Ford.Inbox.Storage.Table
{
    public class MetaDataStoreOptions
    {
        public string TableConnectionString { get; set; }
        public string TableName { get; set; }
    }
}
