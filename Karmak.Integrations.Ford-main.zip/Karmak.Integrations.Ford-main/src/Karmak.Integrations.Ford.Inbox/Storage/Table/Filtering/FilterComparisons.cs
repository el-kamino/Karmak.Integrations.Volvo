namespace Karmak.Integrations.Ford.Inbox.Storage.Table.Filtering;

public enum FilterComparisons
{
    Equal,
    NotEqual,
    GreaterThan,
    GreaterThanOrEqual,
    LessThan,
    LessThanOrEqual
}