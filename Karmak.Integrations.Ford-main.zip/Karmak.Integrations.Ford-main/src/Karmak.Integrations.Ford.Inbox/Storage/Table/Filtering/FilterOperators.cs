namespace Karmak.Integrations.Ford.Inbox.Storage.Table.Filtering;

public enum FilterOperators
{
    And,
    Not,
    Or
}