using Karmak.Integrations.Ford.Oasis.Models;

namespace Karmak.Integrations.Ford.Oasis.Services
{
    public interface ISymptomCodeProvider
    {
        Task<List<CodeLookupRest>> GetSymptomCodesAsync();
    }
}
