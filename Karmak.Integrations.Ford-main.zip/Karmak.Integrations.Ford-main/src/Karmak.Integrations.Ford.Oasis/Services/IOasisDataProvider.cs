using Karmak.Integrations.Ford.Oasis.Models;

namespace Karmak.Integrations.Ford.Oasis.Services
{
    public interface IOasisDataProvider
    {
        Task<OasisResponseRest> GetDataAsync(OasisRequestRest request);
    }
}
