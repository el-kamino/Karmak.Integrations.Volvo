using Karmak.Integrations.Ford.Oasis.Models;
using Karmak.Integrations.Ford.Oasis.Models.Xml;

namespace Karmak.Integrations.Ford.Oasis.Services
{
    public interface IOasisClient
    {
        Task<OasisResponseRest> SendAsync(string oasisUri, OasisRequest request, string karmakAccountNumber = null);
    }
}
