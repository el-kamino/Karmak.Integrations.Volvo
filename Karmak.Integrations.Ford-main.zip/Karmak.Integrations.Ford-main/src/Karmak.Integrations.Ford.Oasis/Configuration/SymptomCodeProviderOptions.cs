﻿namespace Karmak.Integrations.Ford.Oasis.Configuration
{
    public class SymptomCodeProviderOptions
    {
        public string BlobPath { get; set; }
    }
}
