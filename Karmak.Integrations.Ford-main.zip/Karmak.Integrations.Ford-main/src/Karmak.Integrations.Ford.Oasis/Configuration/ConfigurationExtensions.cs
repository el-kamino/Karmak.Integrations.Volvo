using Karmak.Integrations.Ford.Oasis.Mapping;
using Karmak.Integrations.Ford.Oasis.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Karmak.Integrations.Ford.Oasis.Configuration
{
    public static partial class ConfigurationExtensions
    {
        public static IServiceCollection AddOasisServices(this IServiceCollection services, IConfiguration config)
        {
            services.Configure<SymptomCodeProviderOptions>(options =>
            {
                options.BlobPath = config["Ford:Oasis:SymptomCodesBlobPath"];
            });

            services.Configure<OasisDataProviderOptions>(options =>
            {
                options.ApplicationId = config["Ford:Oasis:Client:ApplicationId"];
                options.ImsRegion = config["Ford:Oasis:Client:ImsRegion"];
                options.Uri = config["Ford:Oasis:Client:Uri"];
                options.UserId = config["Ford:Oasis:Client:UserId"];
            });

            services.AddSingleton<IOasisRequestMapper, OasisRequestMapper>();
            services.AddTransient<ISymptomCodeProvider, SymptomCodeProvider>();
            services.AddScoped<IOasisDataProvider, OasisDataProvider>();

            if (config.GetValue<bool>("Ford:Oasis:IsEnabled"))
            {
                services.AddScoped<IOasisClient, OasisClient>();
            }
            else
            {
                services.AddSingleton<IOasisClient, NullOasisClient>();
            }

            return services;
        }
    }
}
