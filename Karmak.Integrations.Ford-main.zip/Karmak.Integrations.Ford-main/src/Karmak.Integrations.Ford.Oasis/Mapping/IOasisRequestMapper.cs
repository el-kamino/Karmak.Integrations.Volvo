using Karmak.Integrations.Ford.Oasis.Models;
using Karmak.Integrations.Ford.Oasis.Models.Xml;

namespace Karmak.Integrations.Ford.Oasis.Mapping
{
    public interface IOasisRequestMapper
    {
        OasisRequest Map(OasisRequestRest source);
    }
}
