﻿namespace Karmak.Integrations.Ford.Oasis
{
    public static class TelemetryValues
    {
        public const string Ford = "Ford";
        public const string Oasis = "Oasis";
    }
}
