﻿namespace Karmak.Integrations.Ford.Oasis.Exceptions
{
    public class OasisOwsSoapException : Exception
    {
        public OasisOwsSoapException(string message, string faultType) : base($"OWS Retrieval Exception [{faultType}]: {message}")
        {
        }
    }
}
