namespace Karmak.Integrations.Ford.Oasis.Exceptions
{
    [Serializable]
    public class OasisConfigException : Exception
    {
        public OasisConfigException()
        {
        }

        public OasisConfigException(string message) : base(message)
        {
        }
    }
}
