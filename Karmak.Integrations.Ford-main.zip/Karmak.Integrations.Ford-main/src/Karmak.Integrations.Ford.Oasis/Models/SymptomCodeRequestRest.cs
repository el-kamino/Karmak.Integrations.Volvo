namespace Karmak.Integrations.Ford.Oasis.Models
{
    public class SymptomCodeRequestRest
    {
        public int Order { get; set; }

        public string Code { get; set; }
    }
}
