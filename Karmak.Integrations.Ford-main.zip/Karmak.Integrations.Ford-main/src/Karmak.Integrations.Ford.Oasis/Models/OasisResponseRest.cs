namespace Karmak.Integrations.Ford.Oasis.Models
{
    public class OasisResponseRest
    {
        public string Payload { get; set; }
    }
}
