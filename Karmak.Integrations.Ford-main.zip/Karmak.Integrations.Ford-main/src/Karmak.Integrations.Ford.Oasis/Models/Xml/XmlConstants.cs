namespace Karmak.Integrations.Ford.Oasis.Models.Xml
{
    public static class XmlConstants
    {
        public const string BooleanYes = "Y";
        public const string BooleanNo = "N";
    }
}
