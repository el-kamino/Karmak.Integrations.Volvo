namespace Karmak.Integrations.Ford.Oasis.Models
{
    public class ComplaintCodeRest
    {
        public string Code { get; set; }

        public string CodeType { get; set; }

        public string Description { get; set; }
    }
}
