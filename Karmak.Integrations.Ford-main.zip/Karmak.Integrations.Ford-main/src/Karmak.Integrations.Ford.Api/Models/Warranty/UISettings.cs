namespace Karmak.Integrations.Ford.Api.Models.Warranty
{
    public class UISettings
    {
        public bool AllowOasisRetrieval { get; set; }
        public string DealerCode { get; set; }
    }
}
