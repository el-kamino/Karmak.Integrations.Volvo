﻿namespace Karmak.Integrations.Ford.Api.Models.React;

public class CustomerUpdateRetransmitRequest
{
    public DateTime? WindowStart { get; set; }
    public DateTime? WindowEnd { get; set; }
    public string[] FordPassIds { get; set; }
    public string[] VINs { get; set; }
    public string PaCode { get; set; }

    public CustomerUpdateRetransmitRequest()
    {
        FordPassIds = Array.Empty<string>();
        VINs = Array.Empty<string>();
    }
}
