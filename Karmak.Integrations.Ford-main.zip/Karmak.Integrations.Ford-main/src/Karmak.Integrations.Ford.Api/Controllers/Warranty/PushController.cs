using System.Net.Mime;
using System.Xml;
using Karmak.Integrations.Ford.Api.Configuration;
using Karmak.Integrations.Ford.Warranty.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Karmak.Integrations.Ford.Api.Controllers.Warranty
{
    [ApiController]
    [Route("/api/FordWarrantyService/v1/Warranty/push")]
    [Authorize(AuthenticationSchemes = SecurityExtensions.FordCertScheme)]
    public class PushController : ControllerBase
    {
        private readonly IFordPushUpdateService _service;

        public PushController(IFordPushUpdateService service)
        {
            _service = service ?? throw new ArgumentNullException(nameof(service));
        }

        [HttpPost]
        [Produces("application/xml")]
        public async Task<IActionResult> Post()
        {
            var pushUpdate = await TryReadPushUpdate();
            var (success, response) = await _service.HandleUpdate(pushUpdate);
            return new ContentResult
            {
                StatusCode = success ? StatusCodes.Status200OK : StatusCodes.Status500InternalServerError,
                ContentType = MediaTypeNames.Application.Xml,
                Content = response.OuterXml
            };
        }

        private async Task<XmlDocument> TryReadPushUpdate()
        {
            var requestBody = new XmlDocument
            {
                PreserveWhitespace = true
            };

            using (var stream = new StreamReader(Request.Body))
            {
                requestBody.LoadXml(await stream.ReadToEndAsync());
            }

            return requestBody;
        }
    }
}
