﻿using Microsoft.AspNetCore.Mvc;

namespace Karmak.Integrations.Ford.Api.Controllers
{
    [Route("healthcheck")]
    [ApiController]
    public class HealthCheckController : ControllerBase
    {
        public IActionResult Get()
        {
            return Ok();
        }
    }
}
