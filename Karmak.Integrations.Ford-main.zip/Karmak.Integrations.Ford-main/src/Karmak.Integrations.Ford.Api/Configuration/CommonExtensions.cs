using Azure.Core;
using Karmak.ELK.Core.KICQ.Api.Core.Settings;
using Karmak.Integrations.Ford.Common.BlobClient;
using Karmak.Integrations.Ford.Common.Settings;
using Karmak.Integrations.Ford.Common.Sql;
using Karmak.Integrations.Ford.Common.Sql.Migrations;
using Microsoft.Extensions.Options;

namespace Karmak.Integrations.Ford.Api.Configuration
{
    public static class CommonExtensions
    {
        public static IServiceCollection ConfigureCommonServices(this IServiceCollection services, IConfiguration config, TokenCredential credential)
        {
            services.Configure<KarmakSettingsProviderOptions>(options =>
            {
                options.CacheTimeout = TimeSpan.FromMinutes(config.GetValue<int>("Ford:Settings:CacheExpirationMinutes"));
                options.Credential = credential;
                options.SettingsServiceResourceId = config["Ford:Settings:ResourceId"];
                options.Url = config["Ford:Settings:Url"];
            });

            services.AddHttpClient<ISettingsProvider, KarmakSettingsProvider>();
            return services;
        }

        public static IServiceCollection ConfigureSqlDataLayer(this IServiceCollection services, IConfiguration config)
        {
            services.Configure<SqlDataLayerOptions>(options =>
            {
                options.ConnectionString = config["Ford:Sql:ConnectionString"];
                options.CommandTimeoutSeconds = config.GetValue("Ford:Sql:CommandTimeoutSeconds", options.CommandTimeoutSeconds);
                options.MigrationCommandTimeoutSeconds = config.GetValue("Ford:Sql:MigrationCommandTimeoutSeconds", options.MigrationCommandTimeoutSeconds);
                options.MigrationLockTimeoutSeconds = config.GetValue("Ford:Sql:MigrationLockTimeoutSeconds", options.MigrationLockTimeoutSeconds);
            });

            services.Configure<ReactDataCleanupOptions>(options =>
            {
                options.Enabled = config.GetValue("Ford:Sql:Cleanup:Enabled", options.Enabled);
                options.RunAtUtc = config.GetValue("Ford:Sql:Cleanup:RunAtUtc", options.RunAtUtc);
                options.RetentionDays = config.GetValue("Ford:Sql:Cleanup:RetentionDays", options.RetentionDays);
                options.BatchSize = config.GetValue("Ford:Sql:Cleanup:BatchSize", options.BatchSize);
            });

            services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
            services.AddSingleton<ISqlMigrationRunner, SqlMigrationRunner>();
            services.AddSingleton<IReactDataRepository, ReactDataRepository>();
            services.AddSingleton<IWarrantyDataRepository, WarrantyDataRepository>();

            return services;
        }

        public static IServiceCollection ConfigureStorage(this IServiceCollection services, IConfiguration config, TokenCredential credential)
        {
            services.Configure<ExternalBlobClientOptions>(options =>
            {
                options.ContainerName = config["Ford:Storage:ExternalUploadContainerName"];
                options.BlobServiceUri = config["Ford:Storage:BlobServiceUri"];
                options.Credential = credential;
            });

            services.AddSingleton<IExternalBlobClient, ExternalBlobClient>();

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("ClaimCheck", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:Storage:ClaimCheckContainerName"],
                            StorageConnectionString = config["Ford:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("FordReact", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:Storage:ReactContainerName"],
                            StorageConnectionString = config["Ford:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("StandardCodes", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:Storage:StandardCodesContainerName"],
                            StorageConnectionString = config["Ford:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("SymptomCodes", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:Storage:SymptomCodesContainerName"],
                            StorageConnectionString = config["Ford:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("InboxUIBlobClient", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:UI:Storage:InboxContainerName"],
                            StorageConnectionString = config["Ford:UI:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("OasisUIBlobClient", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:UI:Storage:OasisContainerName"],
                            StorageConnectionString = config["Ford:UI:Storage:ConnectionString"]
                        }));

                return client;
            });

            services.AddKeyedSingleton<IKarmakBlobClient, KarmakBlobClient>("WarrantyUIBlobClient", (sp, key) =>
            {
                var client = new KarmakBlobClient(
                    Options.Create(
                        new KarmakBlobClientOptions
                        {
                            ContainerName = config["Ford:UI:Storage:WarrantyContainerName"],
                            StorageConnectionString = config["Ford:UI:Storage:ConnectionString"]
                        }));

                return client;
            });

            return services;
        }
    }
}
