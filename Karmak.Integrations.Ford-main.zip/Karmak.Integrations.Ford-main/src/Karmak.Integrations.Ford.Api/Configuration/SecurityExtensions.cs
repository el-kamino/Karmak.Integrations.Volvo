using Karmak.Integrations.Ford.Api.Infrastructure.Authentication;
using Microsoft.Identity.Web;

namespace Karmak.Integrations.Ford.Api.Configuration;

public static class SecurityExtensions
{
    internal const string MicrosoftScheme = "microsoft";
    internal const string FordCertScheme = "fordcert";

    public static IServiceCollection ConfigureSecurity(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient<FordCertJwtBearerEvents>();
        services.Configure<FordCertJwtBearerEventOptions>(options => { options.AuthorityUrl = configuration["Ford:KarmakId:Url"]!; });

        services.AddAuthentication(MicrosoftScheme)
              .AddJwtBearer(FordCertScheme, options =>
              {
                  options.Authority = configuration["Ford:KarmakId:Url"];
                  options.Audience = configuration["Ford:KarmakId:Audience"];
                  options.EventsType = typeof(FordCertJwtBearerEvents);
              })
              .AddMicrosoftIdentityWebApi(configuration, jwtBearerScheme: MicrosoftScheme, configSectionName: "Ford:AzureAd");

        return services;
    }
}
