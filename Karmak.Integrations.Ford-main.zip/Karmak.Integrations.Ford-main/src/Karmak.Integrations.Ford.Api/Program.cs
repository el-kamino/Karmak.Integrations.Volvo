using Azure.Identity;
using Karmak.Integrations.Ford.Api.Configuration;
using Karmak.Integrations.Ford.Api.Infrastructure.Background;
using Karmak.Integrations.Ford.Api.Infrastructure.Middleware;
using Karmak.Integrations.Ford.Api.Infrastructure.Startup;
using Karmak.Integrations.Ford.Dcds.Configuration;
using Karmak.Integrations.Ford.Fusion.Common;
using Karmak.Integrations.Ford.Fusion.Dcds;
using Karmak.Integrations.Ford.Fusion.React;
using Karmak.Integrations.Ford.Inbox.Configuration;
using Karmak.Integrations.Ford.Oasis.Configuration;
using Karmak.Integrations.Ford.React.Configuration;
using Karmak.Integrations.Ford.Warranty.Configuration;

namespace Karmak.Integrations.Ford.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var credential = new DefaultAzureCredential();

            if (builder.Environment.IsProduction())
            {
                builder.Configuration.AddAzureAppConfiguration(
                   options =>
                   {
                       options.Connect(new Uri(builder.Configuration["AppSettingsEndpoint"]!), credential)
                           .Select("Ford:*");

                       options.ConfigureKeyVault(options =>
                       {
                           options.SetCredential(credential);
                       });
                   });
            }

            builder.Services.AddSingleton(TimeProvider.System);

            builder.Services.ConfigureSecurity(builder.Configuration);
            builder.Services.ConfigureLogging(builder.Configuration, credential);
            builder.Services.ConfigureMassTransit(builder.Configuration, credential);
            builder.Services.ConfigureStorage(builder.Configuration, credential);

            builder.Services.AddScoped<ImplicitElkContextMiddleware>();
            builder.Services.AddScoped<UICookieMiddleware>();

            builder.Services.ConfigureCommonServices(builder.Configuration, credential);
            builder.Services.ConfigureSqlDataLayer(builder.Configuration);
            builder.Services.AddFordReactDispatch(builder.Configuration);
            builder.Services.AddFordDcdsDispatch(builder.Configuration);
            builder.Services.AddCommonDispatchers(builder.Configuration);
            builder.Services.AddFordReactProcessing(builder.Configuration);
            builder.Services.AddFordDcdsServices(builder.Configuration);
            builder.Services.AddFordWarrantyProcessing(builder.Configuration, credential);
            builder.Services.AddOasisServices(builder.Configuration);
            builder.Services.AddInboxServices(builder.Configuration);
            builder.Services.AddHybridCache();
            builder.Services.AddControllers().AddNewtonsoftJson();

            builder.Services.AddHostedService<StorageSetupHostedService>();
            builder.Services.AddHostedService<SqlMigrationHostedService>();
            builder.Services.AddHostedService<ReactDataCleanupHostedService>();

            var app = builder.Build();

            app.UseHttpsRedirection();

            //This needs to run before authentication/authorization
            app.UseMiddleware<UICookieMiddleware>();

            app.UseAuthentication();
            app.UseAuthorization();
            app.UseMiddleware<ImplicitElkContextMiddleware>();

            app.MapControllers();
            app.Run();
        }
    }
}
