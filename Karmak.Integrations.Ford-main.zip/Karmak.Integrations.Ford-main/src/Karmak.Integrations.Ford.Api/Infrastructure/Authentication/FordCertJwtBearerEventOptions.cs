﻿namespace Karmak.Integrations.Ford.Api.Infrastructure.Authentication;

public class FordCertJwtBearerEventOptions
{
    public required string AuthorityUrl { get; set; }
}
